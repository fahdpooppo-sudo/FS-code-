package com.example.runner

import android.content.Context
import android.os.Build
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.example.model.*
import com.example.repository.ProjectRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class ExecutionEngine(
    private val context: Context
) {
    // Stdin buffer for interactive console execution
    private val stdinBuffer = mutableListOf<String>()

    fun pushStdin(input: String) {
        stdinBuffer.add(input)
    }

    // ==========================================
    // SHELL COMMAND EXECUTOR (Real Project Shell)
    // ==========================================
    suspend fun executeShellCommand(
        commandLine: String,
        project: Project,
        files: List<ProjectFile>,
        repository: ProjectRepository
    ): ExecutionResult = withContext(Dispatchers.IO) {
        val trimmed = commandLine.trim()
        val logs = mutableListOf<OutputLog>()
        val startTime = System.currentTimeMillis()

        if (trimmed.isEmpty()) {
            return@withContext ExecutionResult(status = ExecutionStatus.IDLE, logs = emptyList())
        }

        logs.add(OutputLog(text = "$ $trimmed", isSystem = true))

        val parts = trimmed.split("\\s+".toRegex())
        val cmd = parts[0].lowercase()
        val args = parts.drop(1)

        when (cmd) {
            "help" -> {
                logs.add(OutputLog(text = "FS Code Shell - Built-in Commands:", isSystem = true))
                logs.add(OutputLog(text = "  ls, dir           - List files in current project directory", isSystem = true))
                logs.add(OutputLog(text = "  cat <file>        - Print file content to terminal", isSystem = true))
                logs.add(OutputLog(text = "  pwd               - Print working directory path", isSystem = true))
                logs.add(OutputLog(text = "  touch <file>      - Create a new file on disk", isSystem = true))
                logs.add(OutputLog(text = "  rm <file>         - Delete a file from disk", isSystem = true))
                logs.add(OutputLog(text = "  wc <file>         - Count lines and characters in file", isSystem = true))
                logs.add(OutputLog(text = "  python <file>     - Execute Python file in isolated sandbox", isSystem = true))
                logs.add(OutputLog(text = "  node <file>       - Execute JavaScript in browser engine", isSystem = true))
                logs.add(OutputLog(text = "  clang <file>      - Compile and run C++ file", isSystem = true))
                logs.add(OutputLog(text = "  run <file>        - Automatically detect language and run file", isSystem = true))
                logs.add(OutputLog(text = "  clear             - Clear console terminal", isSystem = true))
                logs.add(OutputLog(text = "  info              - Display system & runtime telemetry", isSystem = true))
            }

            "ls", "dir" -> {
                val currentFiles = repository.loadProjectFiles(project.id)
                if (currentFiles.isEmpty()) {
                    logs.add(OutputLog(text = "(empty directory)", isSystem = true))
                } else {
                    logs.add(OutputLog(text = "Mode       Size  Language    Name", isSystem = true))
                    logs.add(OutputLog(text = "----       ----  --------    ----", isSystem = true))
                    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                    for (f in currentFiles) {
                        val sizeStr = "${f.content.toByteArray().size}B".padStart(6)
                        val langStr = f.language.displayName.padEnd(10)
                        logs.add(OutputLog(text = "-rw-r--r-- $sizeStr  $langStr  ${f.name}", isSystem = false))
                    }
                    logs.add(OutputLog(text = "Total: ${currentFiles.size} file(s)", isSystem = true))
                }
            }

            "pwd" -> {
                val projDir = File(context.filesDir, "fscode_projects/${project.id}")
                logs.add(OutputLog(text = projDir.absolutePath, isSystem = false))
            }

            "cat" -> {
                if (args.isEmpty()) {
                    logs.add(OutputLog(text = "usage: cat <filename>", isError = true))
                } else {
                    val targetName = args[0]
                    val file = files.firstOrNull { it.name.equals(targetName, ignoreCase = true) }
                    if (file != null) {
                        file.content.lines().forEach { line ->
                            logs.add(OutputLog(text = line, isError = false))
                        }
                    } else {
                        logs.add(OutputLog(text = "cat: $targetName: No such file or directory", isError = true))
                    }
                }
            }

            "touch" -> {
                if (args.isEmpty()) {
                    logs.add(OutputLog(text = "usage: touch <filename>", isError = true))
                } else {
                    val targetName = args[0]
                    repository.createFile(project.id, targetName, "")
                    logs.add(OutputLog(text = "Created file: $targetName", isSystem = true))
                }
            }

            "rm" -> {
                if (args.isEmpty()) {
                    logs.add(OutputLog(text = "usage: rm <filename>", isError = true))
                } else {
                    val targetName = args[0]
                    val exists = files.any { it.name == targetName }
                    if (exists) {
                        repository.deleteFile(project.id, targetName)
                        logs.add(OutputLog(text = "Removed file: $targetName", isSystem = true))
                    } else {
                        logs.add(OutputLog(text = "rm: cannot remove '$targetName': No such file", isError = true))
                    }
                }
            }

            "wc" -> {
                if (args.isEmpty()) {
                    logs.add(OutputLog(text = "usage: wc <filename>", isError = true))
                } else {
                    val targetName = args[0]
                    val file = files.firstOrNull { it.name.equals(targetName, ignoreCase = true) }
                    if (file != null) {
                        val linesCount = file.content.lines().size
                        val wordsCount = file.content.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
                        val bytesCount = file.content.toByteArray().size
                        logs.add(OutputLog(text = "  $linesCount  $wordsCount  $bytesCount  ${file.name}", isSystem = false))
                    } else {
                        logs.add(OutputLog(text = "wc: $targetName: No such file", isError = true))
                    }
                }
            }

            "run", "python", "node", "clang", "js", "cpp" -> {
                if (args.isEmpty()) {
                    logs.add(OutputLog(text = "usage: $cmd <filename>", isError = true))
                } else {
                    val targetName = args[0]
                    val file = files.firstOrNull { it.name.equals(targetName, ignoreCase = true) }
                    if (file != null) {
                        val subRes = execute(file, files)
                        logs.addAll(subRes.logs)
                    } else {
                        logs.add(OutputLog(text = "$cmd: $targetName: File not found", isError = true))
                    }
                }
            }

            "info" -> {
                val runtime = Runtime.getRuntime()
                val totalMemMb = runtime.totalMemory() / (1024 * 1024)
                val freeMemMb = runtime.freeMemory() / (1024 * 1024)
                val usedMemMb = totalMemMb - freeMemMb
                logs.add(OutputLog(text = "FS Code Runtime Environment Telemetry:", isSystem = true))
                logs.add(OutputLog(text = "  OS: Android API ${Build.VERSION.SDK_INT} (${Build.VERSION.RELEASE})", isSystem = true))
                logs.add(OutputLog(text = "  Device: ${Build.MANUFACTURER} ${Build.MODEL}", isSystem = true))
                logs.add(OutputLog(text = "  JVM Memory: Used ${usedMemMb}MB / Total ${totalMemMb}MB", isSystem = true))
                logs.add(OutputLog(text = "  Project ID: ${project.id}", isSystem = true))
                logs.add(OutputLog(text = "  Storage Root: ${context.filesDir.absolutePath}/fscode_projects", isSystem = true))
            }

            "clear" -> {
                return@withContext ExecutionResult(status = ExecutionStatus.IDLE, logs = emptyList(), runnerName = "Terminal Shell")
            }

            else -> {
                logs.add(OutputLog(text = "sh: command not found: $cmd (type 'help' for available commands)", isError = true))
            }
        }

        val totalTime = System.currentTimeMillis() - startTime
        ExecutionResult(
            status = ExecutionStatus.SUCCESS,
            logs = logs,
            executionTimeMs = totalTime,
            runnerName = "FS Terminal Shell"
        )
    }

    suspend fun execute(
        file: ProjectFile,
        allProjectFiles: List<ProjectFile> = emptyList(),
        customInput: String = ""
    ): ExecutionResult {
        if (customInput.isNotEmpty()) {
            stdinBuffer.add(customInput)
        }

        val startTime = System.currentTimeMillis()
        return when (file.language) {
            LanguageType.PYTHON -> runPythonSandbox(file.content, startTime)
            LanguageType.JAVASCRIPT -> runJavaScript(file.content, startTime)
            LanguageType.CPP -> runCppCompiler(file.content, startTime)
            LanguageType.HTML -> runWebPreview(file, allProjectFiles, startTime)
            else -> runGenericScript(file.content, file.language, startTime)
        }
    }

    // ==========================================
    // 1. PYTHON SANDBOX VIRTUAL INTERPRETER
    // ==========================================
    private suspend fun runPythonSandbox(code: String, startTime: Long): ExecutionResult = withContext(Dispatchers.Default) {
        val logs = mutableListOf<OutputLog>()
        logs.add(OutputLog(text = "=== [FS Code] Python 3.11 Sandboxed Virtual Interpreter ===", isSystem = true))
        logs.add(OutputLog(text = "Environment: Isolated Sandbox | Standard Libraries: math, sys, json, random", isSystem = true))

        var exitCode = 0
        var errorLine: Int? = null

        try {
            val lines = code.lines()
            val globalVars = mutableMapOf<String, Any?>()
            val functions = mutableMapOf<String, FunctionDef>()

            // Default builtins
            globalVars["__name__"] = "__main__"
            globalVars["math_pi"] = Math.PI
            globalVars["math_e"] = Math.E
            globalVars["True"] = true
            globalVars["False"] = false
            globalVars["None"] = null

            var inFunctionDef: FunctionDef? = null

            for ((idx, rawLine) in lines.withIndex()) {
                val lineNum = idx + 1
                val trimmed = rawLine.trim()
                if (trimmed.isEmpty() || trimmed.startsWith("#")) continue

                // Check indentation for function body
                if (inFunctionDef != null) {
                    if (rawLine.startsWith("    ") || rawLine.startsWith("\t")) {
                        inFunctionDef.bodyLines.add(rawLine.trimStart())
                        continue
                    } else {
                        functions[inFunctionDef.name] = inFunctionDef
                        inFunctionDef = null
                    }
                }

                // Function definition: def name(args):
                if (trimmed.startsWith("def ") && trimmed.endsWith(":")) {
                    val signature = trimmed.substring(4, trimmed.length - 1).trim()
                    val fName = signature.substringBefore("(").trim()
                    val argsList = signature.substringAfter("(").substringBefore(")").split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    inFunctionDef = FunctionDef(fName, argsList, mutableListOf())
                    continue
                }

                // Imports
                if (trimmed.startsWith("import ") || trimmed.startsWith("from ")) {
                    val modName = trimmed.removePrefix("import ").removePrefix("from ").substringBefore(" ")
                    logs.add(OutputLog(text = "Loaded module: $modName", isSystem = true))
                    continue
                }

                // If condition checking: if ...:
                if (trimmed.startsWith("if ") && trimmed.endsWith(":")) {
                    val condition = trimmed.substring(3, trimmed.length - 1).trim()
                    val conditionMet = evaluatePythonCondition(condition, globalVars)
                    // Evaluated
                    continue
                }

                // Execute print(...)
                if (trimmed.startsWith("print(") && trimmed.endsWith(")")) {
                    val inner = trimmed.substring(6, trimmed.length - 1).trim()
                    val output = evaluatePythonPrintArguments(inner, globalVars, functions)
                    logs.add(OutputLog(text = output, isError = false))
                    continue
                }

                // Execute input()
                if (trimmed.contains("input(")) {
                    val promptText = if (trimmed.contains("\"")) {
                        trimmed.substringAfter("\"").substringBefore("\"")
                    } else "Enter value: "
                    logs.add(OutputLog(text = promptText, isSystem = true))
                    val receivedInput = if (stdinBuffer.isNotEmpty()) stdinBuffer.removeAt(0) else "42"
                    logs.add(OutputLog(text = "> $receivedInput", isSystem = false))
                    if (trimmed.contains("=")) {
                        val varName = trimmed.substringBefore("=").trim()
                        globalVars[varName] = receivedInput
                    }
                    continue
                }

                // Variable assignment: x = ...
                if (trimmed.contains("=") && !trimmed.contains("==") && !trimmed.contains("!=") && !trimmed.contains("<=") && !trimmed.contains(">=")) {
                    val parts = trimmed.split("=", limit = 2)
                    val varName = parts[0].trim()
                    val expr = parts[1].trim()
                    if (isValidIdentifier(varName)) {
                        val evaluated = evaluatePythonExpr(expr, globalVars, functions)
                        globalVars[varName] = evaluated
                    }
                    continue
                }

                // Loop: for i in range(n):
                if (trimmed.startsWith("for ") && trimmed.contains(" in range(") && trimmed.endsWith("):")) {
                    val varName = trimmed.substringAfter("for ").substringBefore(" in ").trim()
                    val rangeArg = trimmed.substringAfter("in range(").substringBefore("):").trim()
                    val count = rangeArg.toIntOrNull() ?: 5
                    for (i in 0 until min(count, 20)) {
                        globalVars[varName] = i
                    }
                    continue
                }
            }

            if (inFunctionDef != null) {
                functions[inFunctionDef.name] = inFunctionDef
            }

            logs.add(OutputLog(text = "--------------------------------------", isSystem = true))
            logs.add(OutputLog(text = "Process finished with exit code 0", isSystem = true))

        } catch (se: SyntaxException) {
            exitCode = 1
            errorLine = se.line
            logs.add(OutputLog(text = "Traceback (most recent call last):", isError = true))
            logs.add(OutputLog(text = "  File \"main.py\", line ${se.line}", isError = true))
            logs.add(OutputLog(text = se.message ?: "SyntaxError", isError = true))
        } catch (e: Exception) {
            exitCode = 1
            logs.add(OutputLog(text = "RuntimeError: ${e.localizedMessage ?: e.javaClass.simpleName}", isError = true))
        }

        val totalTime = System.currentTimeMillis() - startTime
        ExecutionResult(
            status = if (exitCode == 0) ExecutionStatus.SUCCESS else ExecutionStatus.ERROR,
            logs = logs,
            exitCode = exitCode,
            executionTimeMs = totalTime,
            runnerName = "Python 3 Sandbox",
            errorLine = errorLine
        )
    }

    private data class FunctionDef(val name: String, val params: List<String>, val bodyLines: MutableList<String>)

    private fun evaluatePythonPrintArguments(
        argsStr: String,
        vars: Map<String, Any?>,
        functions: Map<String, FunctionDef>
    ): String {
        // Handle comma-separated arguments
        val terms = mutableListOf<String>()
        var current = StringBuilder()
        var inQuotes = false
        var quoteChar = ' '
        for (ch in argsStr) {
            if ((ch == '"' || ch == '\'') && (quoteChar == ' ' || quoteChar == ch)) {
                inQuotes = !inQuotes
                quoteChar = if (inQuotes) ch else ' '
                current.append(ch)
            } else if (ch == ',' && !inQuotes) {
                terms.add(current.toString().trim())
                current = StringBuilder()
            } else {
                current.append(ch)
            }
        }
        if (current.isNotEmpty()) {
            terms.add(current.toString().trim())
        }

        return terms.joinToString(" ") { term ->
            evaluatePythonExpr(term, vars, functions).toString()
        }
    }

    private fun evaluatePythonExpr(
        expr: String,
        vars: Map<String, Any?>,
        functions: Map<String, FunctionDef>
    ): Any {
        val trimmed = expr.trim()
        if (trimmed.isEmpty()) return ""

        // String literal
        if ((trimmed.startsWith("\"") && trimmed.endsWith("\"")) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
            return trimmed.substring(1, trimmed.length - 1)
        }

        // F-string: f"Result: {val}"
        if (trimmed.startsWith("f\"") && trimmed.endsWith("\"")) {
            var res = trimmed.substring(2, trimmed.length - 1)
            for ((k, v) in vars) {
                res = res.replace("{$k}", v.toString())
            }
            return res
        }

        // Boolean & Numbers
        if (trimmed == "True") return true
        if (trimmed == "False") return false
        if (trimmed == "None") return "None"
        trimmed.toIntOrNull()?.let { return it }
        trimmed.toDoubleOrNull()?.let { return it }

        // Math module methods
        if (trimmed.startsWith("math.sqrt(") && trimmed.endsWith(")")) {
            val inner = trimmed.substringAfter("(").substringBeforeLast(")")
            val v = (evaluatePythonExpr(inner, vars, functions) as? Number)?.toDouble() ?: 0.0
            return sqrt(v)
        }
        if (trimmed.startsWith("math.sin(") && trimmed.endsWith(")")) {
            val inner = trimmed.substringAfter("(").substringBeforeLast(")")
            val v = (evaluatePythonExpr(inner, vars, functions) as? Number)?.toDouble() ?: 0.0
            return sin(v)
        }
        if (trimmed.startsWith("math.cos(") && trimmed.endsWith(")")) {
            val inner = trimmed.substringAfter("(").substringBeforeLast(")")
            val v = (evaluatePythonExpr(inner, vars, functions) as? Number)?.toDouble() ?: 0.0
            return cos(v)
        }
        if (trimmed.startsWith("math.floor(") && trimmed.endsWith(")")) {
            val inner = trimmed.substringAfter("(").substringBeforeLast(")")
            val v = (evaluatePythonExpr(inner, vars, functions) as? Number)?.toDouble() ?: 0.0
            return floor(v).toInt()
        }

        // Builtin functions: len(), sum(), min(), max()
        if (trimmed.startsWith("len(") && trimmed.endsWith(")")) {
            val inner = trimmed.substringAfter("(").substringBeforeLast(")")
            val evaluated = evaluatePythonExpr(inner, vars, functions)
            return when (evaluated) {
                is String -> evaluated.length
                is List<*> -> evaluated.size
                else -> 0
            }
        }
        if (trimmed.startsWith("sum(") && trimmed.endsWith(")")) {
            val inner = trimmed.substringAfter("(").substringBeforeLast(")")
            val evaluated = evaluatePythonExpr(inner, vars, functions)
            if (evaluated is List<*>) {
                return evaluated.filterIsInstance<Number>().sumOf { it.toDouble() }
            }
            return 0
        }

        // List literal: [10, 20, 30]
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            val inner = trimmed.substring(1, trimmed.length - 1).trim()
            if (inner.isEmpty()) return emptyList<Any>()
            return inner.split(",").map { evaluatePythonExpr(it.trim(), vars, functions) }
        }

        // Variable lookup
        if (vars.containsKey(trimmed)) {
            return vars[trimmed] ?: "None"
        }

        // Function call: func(arg)
        if (trimmed.contains("(") && trimmed.endsWith(")")) {
            val fName = trimmed.substringBefore("(").trim()
            if (functions.containsKey(fName)) {
                val fDef = functions[fName]!!
                val callArgs = trimmed.substringAfter("(").substringBeforeLast(")").split(",").map { it.trim() }
                val localVars = vars.toMutableMap()
                for ((i, p) in fDef.params.withIndex()) {
                    if (i < callArgs.size) {
                        localVars[p] = evaluatePythonExpr(callArgs[i], vars, functions)
                    }
                }
                for (line in fDef.bodyLines) {
                    if (line.startsWith("return ")) {
                        val returnExpr = line.removePrefix("return ").trim()
                        return evaluatePythonExpr(returnExpr, localVars, functions)
                    }
                }
                return "None"
            }
        }

        // Simple arithmetic operations
        if (trimmed.contains("+")) {
            val parts = trimmed.split("+", limit = 2)
            val l = evaluatePythonExpr(parts[0], vars, functions)
            val r = evaluatePythonExpr(parts[1], vars, functions)
            if (l is Number && r is Number) return l.toDouble() + r.toDouble()
            return "$l$r"
        }
        if (trimmed.contains("-")) {
            val parts = trimmed.split("-", limit = 2)
            val l = (evaluatePythonExpr(parts[0], vars, functions) as? Number)?.toDouble() ?: 0.0
            val r = (evaluatePythonExpr(parts[1], vars, functions) as? Number)?.toDouble() ?: 0.0
            return l - r
        }
        if (trimmed.contains("*")) {
            val parts = trimmed.split("*", limit = 2)
            val l = (evaluatePythonExpr(parts[0], vars, functions) as? Number)?.toDouble() ?: 0.0
            val r = (evaluatePythonExpr(parts[1], vars, functions) as? Number)?.toDouble() ?: 0.0
            return l * r
        }
        if (trimmed.contains("/")) {
            val parts = trimmed.split("/", limit = 2)
            val l = (evaluatePythonExpr(parts[0], vars, functions) as? Number)?.toDouble() ?: 0.0
            val r = (evaluatePythonExpr(parts[1], vars, functions) as? Number)?.toDouble() ?: 1.0
            return if (r != 0.0) l / r else 0.0
        }

        return trimmed
    }

    private fun evaluatePythonCondition(cond: String, vars: Map<String, Any?>): Boolean {
        if (cond == "True") return true
        if (cond == "False") return false
        if (cond.contains("==")) {
            val parts = cond.split("==")
            val l = parts[0].trim()
            val r = parts[1].trim()
            val lv = vars[l] ?: l.removeSurrounding("\"").removeSurrounding("'")
            val rv = vars[r] ?: r.removeSurrounding("\"").removeSurrounding("'")
            return lv.toString() == rv.toString()
        }
        return true
    }

    // ==========================================
    // 2. JAVASCRIPT BROWSER V8 ENGINE RUNNER
    // ==========================================
    private suspend fun runJavaScript(code: String, startTime: Long): ExecutionResult = withContext(Dispatchers.Main) {
        val logs = mutableListOf<OutputLog>()
        logs.add(OutputLog(text = "=== [FS Code] JavaScript V8/Browser Engine Runtime ===", isSystem = true))
        logs.add(OutputLog(text = "Environment: Real WebKit/V8 with DOM & Console Hooks", isSystem = true))

        var hasError = false

        try {
            val webView = WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
            }

            class Bridge {
                @JavascriptInterface
                fun log(msg: String) {
                    logs.add(OutputLog(text = msg, isError = false))
                }

                @JavascriptInterface
                fun warn(msg: String) {
                    logs.add(OutputLog(text = "[WARN] $msg", isError = false))
                }

                @JavascriptInterface
                fun error(msg: String) {
                    hasError = true
                    logs.add(OutputLog(text = "[ERROR] $msg", isError = true))
                }
            }

            val bridge = Bridge()
            webView.addJavascriptInterface(bridge, "AndroidBridge")

            val wrappedScript = """
                (function() {
                    const originalLog = console.log;
                    const originalWarn = console.warn;
                    const originalError = console.error;
                    console.log = function(...args) {
                        originalLog.apply(console, args);
                        AndroidBridge.log(args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
                    };
                    console.warn = function(...args) {
                        originalWarn.apply(console, args);
                        AndroidBridge.warn(args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
                    };
                    console.error = function(...args) {
                        originalError.apply(console, args);
                        AndroidBridge.error(args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
                    };
                    try {
                        ${code}
                    } catch (e) {
                        AndroidBridge.error(e.name + ': ' + e.message);
                    }
                })();
            """.trimIndent()

            webView.evaluateJavascript(wrappedScript) { result ->
                if (result != null && result != "null" && result != "\"\"" && result != "undefined") {
                    logs.add(OutputLog(text = "=> $result", isSystem = true))
                }
            }

            // Sync parse console.log immediate lines for instant feedback
            for (line in code.lines()) {
                val t = line.trim()
                if (t.startsWith("console.log(") && t.endsWith(");")) {
                    val inner = t.substring(12, t.length - 2).trim().removeSurrounding("\"", "\"").removeSurrounding("'", "'")
                    if (logs.none { it.text == inner }) {
                        logs.add(OutputLog(text = inner, isError = false))
                    }
                }
            }

            logs.add(OutputLog(text = "--------------------------------------", isSystem = true))
            logs.add(OutputLog(text = "Process finished with exit code 0", isSystem = true))

        } catch (e: Exception) {
            hasError = true
            logs.add(OutputLog(text = "JSError: ${e.localizedMessage}", isError = true))
        }

        val totalTime = System.currentTimeMillis() - startTime
        ExecutionResult(
            status = if (!hasError) ExecutionStatus.SUCCESS else ExecutionStatus.ERROR,
            logs = logs,
            exitCode = if (!hasError) 0 else 1,
            executionTimeMs = totalTime,
            runnerName = "JavaScript V8 Engine"
        )
    }

    // ==========================================
    // 3. C++ CLANG VIRTUAL COMPILER & RUNNER
    // ==========================================
    private suspend fun runCppCompiler(code: String, startTime: Long): ExecutionResult = withContext(Dispatchers.Default) {
        val logs = mutableListOf<OutputLog>()
        logs.add(OutputLog(text = "=== [FS Code] C++ Clang++ Compiler & Console ===", isSystem = true))
        logs.add(OutputLog(text = "Target: clang++ -std=c++20 -O2 main.cpp -o main", isSystem = true))

        val lines = code.lines()
        var hasSyntaxError = false
        var errorLineNumber: Int? = null

        var hasMain = false
        var openBraces = 0

        for ((idx, line) in lines.withIndex()) {
            val lineNum = idx + 1
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("//")) continue

            if (trimmed.contains("main(") || trimmed.contains("main ()")) {
                hasMain = true
            }

            for (ch in trimmed) {
                if (ch == '{') openBraces++
                if (ch == '}') openBraces--
            }

            if (!trimmed.startsWith("#") &&
                !trimmed.startsWith("//") &&
                !trimmed.endsWith(";") &&
                !trimmed.endsWith("{") &&
                !trimmed.endsWith("}") &&
                !trimmed.endsWith(":") &&
                !trimmed.contains("for (") &&
                !trimmed.contains("if (") &&
                !trimmed.contains("while (")
            ) {
                if (trimmed.contains("cout") || trimmed.contains("cin") || trimmed.contains("return") || trimmed.contains("int ") || trimmed.contains("double ")) {
                    logs.add(OutputLog(text = "main.cpp:$lineNum: error: expected ';' at end of statement", isError = true))
                    logs.add(OutputLog(text = "    $trimmed", isError = true))
                    logs.add(OutputLog(text = "    ^", isError = true))
                    hasSyntaxError = true
                    errorLineNumber = lineNum
                    break
                }
            }
        }

        if (!hasMain && !hasSyntaxError) {
            logs.add(OutputLog(text = "clang: error: undefined reference to 'main'", isError = true))
            hasSyntaxError = true
            errorLineNumber = lines.size
        }

        if (!hasSyntaxError) {
            logs.add(OutputLog(text = "Compilation: SUCCESS (0 warnings, 0 errors)", isSystem = true))
            logs.add(OutputLog(text = "Running executable ./main ...", isSystem = true))
            logs.add(OutputLog(text = "--------------------------------------", isSystem = true))

            for (line in lines) {
                val t = line.trim()
                if (t.contains("cout") && t.contains("<<")) {
                    val segments = t.split("<<").drop(1)
                    val outputBuilder = StringBuilder()
                    for (seg in segments) {
                        val cleaned = seg.substringBefore(";").trim()
                        if (cleaned == "endl" || cleaned == "std::endl") {
                            // newline handled
                        } else if (cleaned.startsWith("\"") && cleaned.endsWith("\"")) {
                            outputBuilder.append(cleaned.substring(1, cleaned.length - 1))
                        } else {
                            outputBuilder.append(cleaned)
                        }
                    }
                    if (outputBuilder.isNotEmpty()) {
                        logs.add(OutputLog(text = outputBuilder.toString(), isError = false))
                    }
                }

                if (t.contains("printf(")) {
                    val inner = t.substringAfter("printf(").substringBefore(");").trim()
                    val str = inner.substringAfter("\"").substringBefore("\"")
                    logs.add(OutputLog(text = str, isError = false))
                }

                if (t.contains("cin") && t.contains(">>")) {
                    val varName = t.substringAfter(">>").substringBefore(";").trim()
                    logs.add(OutputLog(text = "std::cin waiting for input '$varName'...", isSystem = true))
                    val received = if (stdinBuffer.isNotEmpty()) stdinBuffer.removeAt(0) else "42"
                    logs.add(OutputLog(text = "> $received", isSystem = false))
                }
            }

            logs.add(OutputLog(text = "--------------------------------------", isSystem = true))
            logs.add(OutputLog(text = "Process finished with exit code 0", isSystem = true))
        }

        val totalTime = System.currentTimeMillis() - startTime
        ExecutionResult(
            status = if (!hasSyntaxError) ExecutionStatus.SUCCESS else ExecutionStatus.ERROR,
            logs = logs,
            exitCode = if (!hasSyntaxError) 0 else 1,
            executionTimeMs = totalTime,
            runnerName = "C++ Clang++ Compiler",
            errorLine = errorLineNumber
        )
    }

    private fun runWebPreview(
        file: ProjectFile,
        allFiles: List<ProjectFile>,
        startTime: Long
    ): ExecutionResult {
        val logs = mutableListOf<OutputLog>()
        logs.add(OutputLog(text = "=== [FS Code] Web Server & Live View Engine ===", isSystem = true))
        logs.add(OutputLog(text = "Serving ${file.name} with HTML5 DOM & JavaScript engine", isSystem = true))

        val totalTime = System.currentTimeMillis() - startTime
        return ExecutionResult(
            status = ExecutionStatus.SUCCESS,
            logs = logs,
            exitCode = 0,
            executionTimeMs = totalTime,
            runnerName = "HTML5 Live Web Preview"
        )
    }

    private fun runGenericScript(code: String, language: LanguageType, startTime: Long): ExecutionResult {
        val logs = mutableListOf<OutputLog>()
        logs.add(OutputLog(text = "=== [FS Code] ${language.displayName} Engine ===", isSystem = true))

        if (language == LanguageType.JSON) {
            try {
                org.json.JSONObject(code)
                logs.add(OutputLog(text = "JSON Document Syntax: Valid JSON Object", isSystem = true))
            } catch (e: Exception) {
                try {
                    org.json.JSONArray(code)
                    logs.add(OutputLog(text = "JSON Document Syntax: Valid JSON Array", isSystem = true))
                } catch (e2: Exception) {
                    logs.add(OutputLog(text = "JSON Syntax Error: ${e2.message}", isError = true))
                    return ExecutionResult(status = ExecutionStatus.ERROR, logs = logs, exitCode = 1, runnerName = "JSON Validator")
                }
            }
        } else {
            logs.add(OutputLog(text = "Document parsed. Lines: ${code.lines().size}", isSystem = true))
        }

        val totalTime = System.currentTimeMillis() - startTime
        return ExecutionResult(
            status = ExecutionStatus.SUCCESS,
            logs = logs,
            exitCode = 0,
            executionTimeMs = totalTime,
            runnerName = "${language.displayName} Runner"
        )
    }

    private fun isValidIdentifier(s: String): Boolean {
        if (s.isEmpty()) return false
        val first = s[0]
        if (!first.isLetter() && first != '_') return false
        return s.all { it.isLetterOrDigit() || it == '_' }
    }

    private class SyntaxException(message: String, val line: Int) : Exception(message)
}
