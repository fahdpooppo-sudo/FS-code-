package com.example.localization

import com.example.model.AppLanguage

object AppLocale {
    fun get(key: String, lang: AppLanguage): String {
        return translations[key]?.get(lang) ?: translations[key]?.get(AppLanguage.ENGLISH) ?: key
    }

    private val translations: Map<String, Map<AppLanguage, String>> = mapOf(
        "app_name" to mapOf(
            AppLanguage.ARABIC to "FS Code",
            AppLanguage.TURKISH to "FS Code",
            AppLanguage.ENGLISH to "FS Code"
        ),
        "app_subtitle" to mapOf(
            AppLanguage.ARABIC to "محرر الأكواد وبيئة التطوير من f-Studio",
            AppLanguage.TURKISH to "f-Studio Kod Düzenleyici ve IDE",
            AppLanguage.ENGLISH to "f-Studio Code Editor & IDE"
        ),
        "projects_title" to mapOf(
            AppLanguage.ARABIC to "مشاريعي البرمجية",
            AppLanguage.TURKISH to "Projelerim",
            AppLanguage.ENGLISH to "My Projects"
        ),
        "new_project_btn" to mapOf(
            AppLanguage.ARABIC to "مشروع جديد",
            AppLanguage.TURKISH to "Yeni Proje",
            AppLanguage.ENGLISH to "New Project"
        ),
        "new_project_desc" to mapOf(
            AppLanguage.ARABIC to "ابدأ مشروعاً جديداً مع بيئات بايثون، ويب، أو C++ جاهزة",
            AppLanguage.TURKISH to "Hazır Python, Web veya C++ ortamıyla yeni proje başlat",
            AppLanguage.ENGLISH to "Start a new project with pre-configured Python, Web, or C++ templates"
        ),
        "extensions_btn" to mapOf(
            AppLanguage.ARABIC to "الإضافات",
            AppLanguage.TURKISH to "Eklentiler",
            AppLanguage.ENGLISH to "Extensions"
        ),
        "linked_apps_btn" to mapOf(
            AppLanguage.ARABIC to "التطبيقات المرتبطة (FS Builder)",
            AppLanguage.TURKISH to "Bağlı Uygulamalar (FS Builder)",
            AppLanguage.ENGLISH to "Linked Apps (FS Builder)"
        ),
        "linked_apps_title" to mapOf(
            AppLanguage.ARABIC to "منظومة تطبيقات f-Studio",
            AppLanguage.TURKISH to "f-Studio Uygulama Ekosistemi",
            AppLanguage.ENGLISH to "f-Studio Ecosystem Apps"
        ),
        "settings_title" to mapOf(
            AppLanguage.ARABIC to "إعدادات FS Code",
            AppLanguage.TURKISH to "FS Code Ayarları",
            AppLanguage.ENGLISH to "FS Code Settings"
        ),
        "language_section" to mapOf(
            AppLanguage.ARABIC to "لغة الواجهة",
            AppLanguage.TURKISH to "Arayüz Dili",
            AppLanguage.ENGLISH to "Interface Language"
        ),
        "commands_language_notice" to mapOf(
            AppLanguage.ARABIC to "تنبيه: واجهة التطبيق تدعم العربية والتركية، بينما الأوامر البرمجية والأكواد والمكتبات تظل بصياغتها الأصلية المعتمدة عالمياً.",
            AppLanguage.TURKISH to "Uyarı: Arayüz Türkçeyi destekler, ancak programlama komutları ve sözdizimi orijinal evrensel dilde kalır.",
            AppLanguage.ENGLISH to "Notice: UI supports Arabic and Turkish, while coding commands, syntax, and libraries remain strictly in their native original language."
        ),
        "theme_section" to mapOf(
            AppLanguage.ARABIC to "المظهر والسمات",
            AppLanguage.TURKISH to "Görünüm ve Temalar",
            AppLanguage.ENGLISH to "Appearance & Themes"
        ),
        "dark_mode" to mapOf(
            AppLanguage.ARABIC to "الوضع الداكن الفاخر (افتراضي)",
            AppLanguage.TURKISH to "Lüks Koyu Mod (Varsayılan)",
            AppLanguage.ENGLISH to "Signature Dark Mode (Default)"
        ),
        "editor_font_size" to mapOf(
            AppLanguage.ARABIC to "حجم خط المحرر",
            AppLanguage.TURKISH to "Düzenleyici Yazı Boyutu",
            AppLanguage.ENGLISH to "Editor Font Size"
        ),
        "tab_size" to mapOf(
            AppLanguage.ARABIC to "مسافات Tab",
            AppLanguage.TURKISH to "Tab Boşlukları",
            AppLanguage.ENGLISH to "Tab Indent Spaces"
        ),
        "line_numbers" to mapOf(
            AppLanguage.ARABIC to "أرقام الأسطر",
            AppLanguage.TURKISH to "Satır Numaraları",
            AppLanguage.ENGLISH to "Line Numbers"
        ),
        "word_wrap" to mapOf(
            AppLanguage.ARABIC to "التفاف الأسطر تلقائياً",
            AppLanguage.TURKISH to "Otomatik Satır Kaydırma",
            AppLanguage.ENGLISH to "Word Wrap"
        ),
        "auto_save" to mapOf(
            AppLanguage.ARABIC to "الحفظ التلقائي عند التعديل",
            AppLanguage.TURKISH to "Düzenlemede Otomatik Kaydet",
            AppLanguage.ENGLISH to "Auto-save on Edit"
        ),
        "run_code" to mapOf(
            AppLanguage.ARABIC to "تشغيل",
            AppLanguage.TURKISH to "Çalıştır",
            AppLanguage.ENGLISH to "Run"
        ),
        "console_tab" to mapOf(
            AppLanguage.ARABIC to "وحدة التحكم (Console)",
            AppLanguage.TURKISH to "Konsol (Console)",
            AppLanguage.ENGLISH to "Terminal Console"
        ),
        "web_preview_tab" to mapOf(
            AppLanguage.ARABIC to "معاينة المتصفح (Web Preview)",
            AppLanguage.TURKISH to "Web Önizleme",
            AppLanguage.ENGLISH to "Browser Preview"
        ),
        "diagnostics_tab" to mapOf(
            AppLanguage.ARABIC to "فحص الأخطاء (Diagnostics)",
            AppLanguage.TURKISH to "Tanılama ve Hatalar",
            AppLanguage.ENGLISH to "Diagnostics & Linter"
        ),
        "customize_gui" to mapOf(
            AppLanguage.ARABIC to "تخصيص واجهة اللغة",
            AppLanguage.TURKISH to "Dil Arayüzünü Özelleştir",
            AppLanguage.ENGLISH to "Customize Language GUI"
        ),
        "files_explorer" to mapOf(
            AppLanguage.ARABIC to "ملفات المشروع",
            AppLanguage.TURKISH to "Proje Dosyaları",
            AppLanguage.ENGLISH to "Project Explorer"
        ),
        "new_file" to mapOf(
            AppLanguage.ARABIC to "ملف جديد",
            AppLanguage.TURKISH to "Yeni Dosya",
            AppLanguage.ENGLISH to "New File"
        ),
        "new_folder" to mapOf(
            AppLanguage.ARABIC to "مجلد جديد",
            AppLanguage.TURKISH to "Yeni Klasör",
            AppLanguage.ENGLISH to "New Folder"
        ),
        "clear_logs" to mapOf(
            AppLanguage.ARABIC to "مسح السجل",
            AppLanguage.TURKISH to "Günlüğü Temizle",
            AppLanguage.ENGLISH to "Clear Console"
        ),
        "send_input" to mapOf(
            AppLanguage.ARABIC to "إرسال إلى stdin",
            AppLanguage.TURKISH to "Giriş Gönder",
            AppLanguage.ENGLISH to "Send to stdin"
        ),
        "save_file" to mapOf(
            AppLanguage.ARABIC to "حفظ التغييرات",
            AppLanguage.TURKISH to "Değişiklikleri Kaydet",
            AppLanguage.ENGLISH to "Save Changes"
        ),
        "search_replace" to mapOf(
            AppLanguage.ARABIC to "بحث واستبدال",
            AppLanguage.TURKISH to "Bul ve Değiştir",
            AppLanguage.ENGLISH to "Find & Replace"
        ),
        "installed" to mapOf(
            AppLanguage.ARABIC to "مفعلة",
            AppLanguage.TURKISH to "Etkin",
            AppLanguage.ENGLISH to "Active"
        ),
        "get_extension" to mapOf(
            AppLanguage.ARABIC to "تثبيت الإضافة",
            AppLanguage.TURKISH to "Eklentiyi Kur",
            AppLanguage.ENGLISH to "Install Extension"
        ),
        "delete_project_confirm" to mapOf(
            AppLanguage.ARABIC to "هل أنت متأكد من حذف هذا المشروع؟",
            AppLanguage.TURKISH to "Bu projeyi silmek istediğinizden emin misiniz?",
            AppLanguage.ENGLISH to "Are you sure you want to delete this project?"
        ),
        "cancel" to mapOf(
            AppLanguage.ARABIC to "إلغاء",
            AppLanguage.TURKISH to "İptal",
            AppLanguage.ENGLISH to "Cancel"
        ),
        "delete" to mapOf(
            AppLanguage.ARABIC to "حذف",
            AppLanguage.TURKISH to "Sil",
            AppLanguage.ENGLISH to "Delete"
        ),
        "create" to mapOf(
            AppLanguage.ARABIC to "إنشاء",
            AppLanguage.TURKISH to "Oluştur",
            AppLanguage.ENGLISH to "Create"
        )
    )
}
