package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.runner.ExecutionEngine
import com.example.syntax.SyntaxHighlighter
import com.example.ui.components.*
import com.example.ui.dialogs.CustomizeLanguageGuiDialog
import com.example.ui.theme.*
import kotlinx.coroutines.launch

import com.example.repository.ProjectRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    project: Project,
    files: List<ProjectFile>,
    settings: SettingsState,
    executionEngine: ExecutionEngine,
    repository: ProjectRepository,
    onBack: () -> Unit,
    onSaveFile: (fileName: String, content: String) -> Unit,
    onCreateFile: (fileName: String, content: String) -> Unit,
    onDeleteFile: (fileName: String) -> Unit,
    onExportZip: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Opened tabs
    var openFileNames by remember(files) {
        val initial = if (files.isNotEmpty()) listOf(files.first().name) else emptyList()
        mutableStateOf(initial)
    }
    var activeFileName by remember(files) {
        mutableStateOf(files.firstOrNull()?.name ?: "")
    }

    // Active file object
    val activeFile = files.firstOrNull { it.name == activeFileName } ?: files.firstOrNull()

    // Editor content text field state
    var editorTextValue by remember(activeFile?.name) {
        mutableStateOf(TextFieldValue(activeFile?.content ?: ""))
    }

    // Language toolbars customization state
    var languageToolbars by remember {
        mutableStateOf(DefaultLanguageToolbars.getDefaultConfigs())
    }

    // Execution results
    var executionResult by remember { mutableStateOf(ExecutionResult()) }
    var isExecuting by remember { mutableStateOf(false) }

    // Bottom panel view mode: NONE, CONSOLE, WEB_PREVIEW, DIAGNOSTICS
    var bottomPanelMode by remember { mutableStateOf("CONSOLE") }

    // UI Drawer and Dialog states
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    var showCustomizeGuiDialog by remember { mutableStateOf(false) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var newFileNameInput by remember { mutableStateOf("") }
    var showSearchReplace by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var replaceQuery by remember { mutableStateOf("") }

    // Compute active language
    val activeLanguage = activeFile?.language ?: LanguageType.PYTHON

    // Intercept hardware/system back button
    BackHandler {
        if (drawerState.isOpen) {
            coroutineScope.launch { drawerState.close() }
        } else if (bottomPanelMode != "NONE") {
            bottomPanelMode = "NONE"
        } else {
            onBack()
        }
    }

    // Auto-save debounced or on edit if enabled
    fun commitSave(newContent: String) {
        if (activeFile != null) {
            onSaveFile(activeFile.name, newContent)
        }
    }

    // Run execution function
    fun executeCurrentFile() {
        if (activeFile == null) return
        coroutineScope.launch {
            isExecuting = true
            // Save before running
            commitSave(editorTextValue.text)
            // Open relevant panel
            if (activeFile.language == LanguageType.HTML) {
                bottomPanelMode = "WEB_PREVIEW"
            } else {
                bottomPanelMode = "CONSOLE"
            }

            val updatedFile = activeFile.copy(content = editorTextValue.text)
            val res = executionEngine.execute(updatedFile, files)
            executionResult = res
            isExecuting = false
        }
    }

    // Smart suggestions calculation based on cursor word
    val cursorIndex = editorTextValue.selection.start
    val currentWord = remember(editorTextValue.text, cursorIndex) {
        val text = editorTextValue.text
        if (cursorIndex in 1..text.length) {
            val left = text.substring(0, cursorIndex)
            left.takeLastWhile { it.isLetterOrDigit() || it == '_' }
        } else ""
    }

    val smartSuggestions = remember(currentWord, activeLanguage) {
        if (currentWord.length >= 2) {
            (activeLanguage.defaultKeywords + activeLanguage.commonSnippets)
                .filter { it.startsWith(currentWord, ignoreCase = true) }
        } else emptyList()
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = FsSurfaceDark,
                modifier = Modifier.width(280.dp)
            ) {
                FileExplorerDrawer(
                    project = project,
                    files = files,
                    activeFileId = activeFileName,
                    onFileSelected = { file ->
                        if (!openFileNames.contains(file.name)) {
                            openFileNames = openFileNames + file.name
                        }
                        activeFileName = file.name
                        coroutineScope.launch { drawerState.close() }
                    },
                    onNewFileClick = { showNewFileDialog = true },
                    onDeleteFile = { fileName ->
                        onDeleteFile(fileName)
                        openFileNames = openFileNames - fileName
                        if (activeFileName == fileName) {
                            activeFileName = openFileNames.firstOrNull() ?: ""
                        }
                    },
                    onExportZip = onExportZip
                )
            }
        }
    ) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            containerColor = FsBackgroundDark,
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(FsSurfaceDark)
                        .statusBarsPadding()
                ) {
                    // Top App Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
                        }

                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Menu, contentDescription = "Files Drawer", tint = FsTextPrimaryDark)
                        }

                        Column(modifier = Modifier.weight(1f).padding(start = 4.dp)) {
                            Text(
                                text = project.name,
                                color = FsTextSecondaryDark,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = activeFileName.ifEmpty { "No file" },
                                    color = FsTextPrimaryDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1
                                )
                                if (editorTextValue.text != (activeFile?.content ?: "")) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(GoldPrimary)
                                    )
                                }
                            }
                        }

                        // Save button
                        IconButton(
                            onClick = {
                                commitSave(editorTextValue.text)
                                Toast.makeText(context, "Saved ${activeFileName}", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save", tint = GoldPrimary)
                        }

                        // Search & Replace button
                        IconButton(
                            onClick = { showSearchReplace = !showSearchReplace },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = "Find & Replace",
                                tint = if (showSearchReplace) GoldPrimary else FsTextSecondaryDark
                            )
                        }

                        // PRIMARY RUN BUTTON
                        Button(
                            onClick = { executeCurrentFile() },
                            enabled = !isExecuting,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldPrimary,
                                contentColor = Color(0xFF1E1705)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(
                                imageVector = if (isExecuting) Icons.Default.HourglassEmpty else Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isExecuting) "Running..." else "Run",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Search & Replace bar if active
                    AnimatedVisibility(visible = showSearchReplace) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(FsSurfaceVariantDark)
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = { Text("Find...", color = FsTextMutedDark, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f).height(42.dp),
                                    textStyle = TextStyle(color = FsTextPrimaryDark, fontSize = 12.sp),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                OutlinedTextField(
                                    value = replaceQuery,
                                    onValueChange = { replaceQuery = it },
                                    placeholder = { Text("Replace...", color = FsTextMutedDark, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f).height(42.dp),
                                    textStyle = TextStyle(color = FsTextPrimaryDark, fontSize = 12.sp),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = {
                                        if (searchQuery.isNotEmpty()) {
                                            val newText = editorTextValue.text.replace(searchQuery, replaceQuery)
                                            editorTextValue = TextFieldValue(newText)
                                            commitSave(newText)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1705)),
                                    modifier = Modifier.height(42.dp)
                                ) {
                                    Text("All", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Tabs Bar
                    if (openFileNames.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF111318))
                                .horizontalScroll(rememberScrollState())
                        ) {
                            openFileNames.forEach { fName ->
                                val isActive = fName == activeFileName
                                val targetFile = files.firstOrNull { it.name == fName }
                                val langColor = Color(targetFile?.language?.badgeColorHex ?: 0xFF888888)

                                Surface(
                                    modifier = Modifier
                                        .clickable {
                                            activeFileName = fName
                                        },
                                    color = if (isActive) FsSurfaceDark else Color(0xFF111318),
                                    border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark) else null
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(langColor)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = fName,
                                            color = if (isActive) GoldPrimary else FsTextSecondaryDark,
                                            fontSize = 12.sp,
                                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
                                        )

                                        if (openFileNames.size > 1) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Close Tab",
                                                tint = FsTextMutedDark,
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clickable {
                                                        val remaining = openFileNames - fName
                                                        openFileNames = remaining
                                                        if (activeFileName == fName) {
                                                            activeFileName = remaining.firstOrNull() ?: ""
                                                        }
                                                    }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Customizable per-language action bar!
                    val toolbarButtons = languageToolbars[activeLanguage] ?: emptyList()
                    LanguageCustomToolbar(
                        language = activeLanguage,
                        buttons = toolbarButtons,
                        isRunning = isExecuting,
                        onActionClick = { action, template ->
                            when (action) {
                                ToolActionType.RUN_MAIN,
                                ToolActionType.RUN_IN_BROWSER,
                                ToolActionType.COMPILE_CONSOLE -> executeCurrentFile()
                                ToolActionType.WEB_PREVIEW -> {
                                    bottomPanelMode = if (bottomPanelMode == "WEB_PREVIEW") "NONE" else "WEB_PREVIEW"
                                }
                                ToolActionType.FORMAT_CODE -> {
                                    val formatted = formatCode(editorTextValue.text, activeLanguage, settings.tabSize)
                                    editorTextValue = TextFieldValue(formatted)
                                    commitSave(formatted)
                                    Toast.makeText(context, "Code Formatted", Toast.LENGTH_SHORT).show()
                                }
                                ToolActionType.TOGGLE_COMMENT -> {
                                    val commented = toggleComment(editorTextValue.text, activeLanguage)
                                    editorTextValue = TextFieldValue(commented)
                                    commitSave(commented)
                                }
                                ToolActionType.INDENT_FORWARD -> {
                                    val indented = indentText(editorTextValue.text, settings.tabSize)
                                    editorTextValue = TextFieldValue(indented)
                                    commitSave(indented)
                                }
                                ToolActionType.INDENT_BACKWARD -> {
                                    val dedented = dedentText(editorTextValue.text, settings.tabSize)
                                    editorTextValue = TextFieldValue(dedented)
                                    commitSave(dedented)
                                }
                                ToolActionType.INSERT_SNIPPET -> {
                                    val current = editorTextValue.text
                                    val sel = editorTextValue.selection.start
                                    val newText = current.substring(0, sel) + template + current.substring(sel)
                                    editorTextValue = TextFieldValue(newText, TextRange(sel + template.length))
                                    commitSave(newText)
                                }
                                ToolActionType.CLEAR_CONSOLE -> {
                                    executionResult = ExecutionResult()
                                }
                                ToolActionType.VIEW_STATS -> {
                                    val linesCount = editorTextValue.text.lines().size
                                    val charsCount = editorTextValue.text.length
                                    Toast.makeText(context, "Lines: $linesCount | Characters: $charsCount", Toast.LENGTH_LONG).show()
                                }
                                else -> {}
                            }
                        },
                        onCustomizeClick = { showCustomizeGuiDialog = true }
                    )

                    HorizontalDivider(color = FsBorderDark, thickness = 0.5.dp)
                }
            },
            bottomBar = {
                // Smart keyboard symbol accessory bar pinned above bottom/IME
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .imePadding()
                ) {
                    // Status bar: Cursor Position Line:Col & Language
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(FsSurfaceDark)
                            .padding(horizontal = 12.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val textBeforeCursor = editorTextValue.text.take(editorTextValue.selection.start)
                        val lineNum = textBeforeCursor.count { it == '\n' } + 1
                        val colNum = editorTextValue.selection.start - (textBeforeCursor.lastIndexOf('\n').takeIf { it != -1 } ?: -1)

                        Text(
                            text = "Ln $lineNum, Col $colNum  •  UTF-8  •  Spaces: ${settings.tabSize}",
                            color = FsTextMutedDark,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        // Bottom tabs toggle buttons
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .clickable {
                                        bottomPanelMode = if (bottomPanelMode == "CONSOLE") "NONE" else "CONSOLE"
                                    },
                                color = if (bottomPanelMode == "CONSOLE") GoldContainer else Color.Transparent
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Terminal, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Console", fontSize = 10.sp, color = if (bottomPanelMode == "CONSOLE") OnGoldContainer else FsTextSecondaryDark)
                                }
                            }

                            if (activeLanguage == LanguageType.HTML || files.any { it.name.endsWith(".html") }) {
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .clickable {
                                            bottomPanelMode = if (bottomPanelMode == "WEB_PREVIEW") "NONE" else "WEB_PREVIEW"
                                        },
                                    color = if (bottomPanelMode == "WEB_PREVIEW") GoldContainer else Color.Transparent
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Language, contentDescription = null, tint = SyntaxOperator, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Preview", fontSize = 10.sp, color = if (bottomPanelMode == "WEB_PREVIEW") OnGoldContainer else FsTextSecondaryDark)
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = FsBorderDark, thickness = 0.5.dp)

                    // Smart Symbol Bar
                    SmartSymbolBar(
                        language = activeLanguage,
                        tabSize = settings.tabSize,
                        suggestions = smartSuggestions,
                        onInsertText = { token ->
                            val current = editorTextValue.text
                            val sel = editorTextValue.selection.start
                            val newText = current.substring(0, sel) + token + current.substring(sel)
                            editorTextValue = TextFieldValue(newText, TextRange(sel + token.length))
                            if (settings.autoSave) {
                                commitSave(newText)
                            }
                        }
                    )
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Code Editor Area
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(if (bottomPanelMode == "NONE") 1f else 0.55f)
                        .background(FsBackgroundDark)
                ) {
                    val codeScrollState = rememberScrollState()
                    val lines = editorTextValue.text.lines()

                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(codeScrollState)
                    ) {
                        // Line numbers gutter
                        if (settings.showLineNumbers) {
                            Column(
                                modifier = Modifier
                                    .background(Color(0xFF13151C))
                                    .padding(horizontal = 10.dp, vertical = 12.dp)
                                    .widthIn(min = 36.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                for (i in 1..lines.size) {
                                    val isErrorLine = executionResult.errorLine == i
                                    Text(
                                        text = "$i",
                                        color = if (isErrorLine) StatusError else FsTextMutedDark,
                                        fontSize = settings.editorFontSize.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = (settings.editorFontSize * 1.5).sp,
                                        fontWeight = if (isErrorLine) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .fillMaxHeight()
                                    .background(FsBorderDark)
                            )
                        }

                        // Text Field with syntax visual transformation
                        val visualTransformation = remember(activeLanguage, searchQuery) {
                            VisualTransformation { text ->
                                val annotated = SyntaxHighlighter.highlight(
                                    code = text.text,
                                    language = activeLanguage,
                                    searchQuery = searchQuery
                                )
                                TransformedText(annotated, OffsetMapping.Identity)
                            }
                        }

                        val hScroll = rememberScrollState()
                        BasicTextField(
                            value = editorTextValue,
                            onValueChange = { newVal ->
                                editorTextValue = newVal
                                if (settings.autoSave) {
                                    commitSave(newVal.text)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .then(if (!settings.wordWrap) Modifier.horizontalScroll(hScroll) else Modifier)
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            textStyle = TextStyle(
                                color = FsTextPrimaryDark,
                                fontSize = settings.editorFontSize.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = (settings.editorFontSize * 1.5).sp
                            ),
                            cursorBrush = SolidColor(GoldPrimary),
                            visualTransformation = visualTransformation
                        )
                    }
                }

                // Bottom Panels: Console / Web Preview
                AnimatedVisibility(visible = bottomPanelMode != "NONE") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.45f)
                            .background(FsSurfaceDark)
                    ) {
                        when (bottomPanelMode) {
                            "CONSOLE" -> {
                                ConsoleOutputView(
                                    result = executionResult,
                                    isRunning = isExecuting,
                                    onClearLogs = { executionResult = ExecutionResult() },
                                    onSendStdin = { input ->
                                        coroutineScope.launch {
                                            val trimmed = input.trim()
                                            val isShellCommand = trimmed.startsWith("ls") || trimmed.startsWith("dir") ||
                                                    trimmed.startsWith("cat ") || trimmed == "pwd" ||
                                                    trimmed.startsWith("touch ") || trimmed.startsWith("rm ") ||
                                                    trimmed.startsWith("wc ") || trimmed == "help" ||
                                                    trimmed == "info" || trimmed == "clear" ||
                                                    trimmed.startsWith("run ") || trimmed.startsWith("python ") ||
                                                    trimmed.startsWith("node ") || trimmed.startsWith("clang ")

                                            if (isShellCommand) {
                                                val shellRes = executionEngine.executeShellCommand(trimmed, project, files, repository)
                                                if (trimmed == "clear") {
                                                    executionResult = ExecutionResult(runnerName = "FS Terminal Shell")
                                                } else {
                                                    executionResult = executionResult.copy(
                                                        logs = executionResult.logs + shellRes.logs,
                                                        runnerName = "FS Terminal Shell"
                                                    )
                                                }
                                            } else {
                                                executionEngine.pushStdin(input)
                                                executeCurrentFile()
                                            }
                                        }
                                    },
                                    onErrorLineClick = { line ->
                                        Toast.makeText(context, "Error on line $line", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                            "WEB_PREVIEW" -> {
                                if (activeFile != null) {
                                    WebPreviewView(
                                        activeFile = activeFile,
                                        allFiles = files
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Customize Language GUI Dialog
    if (showCustomizeGuiDialog) {
        CustomizeLanguageGuiDialog(
            language = activeLanguage,
            currentButtons = languageToolbars[activeLanguage] ?: emptyList(),
            onSaveButtons = { updated ->
                languageToolbars = languageToolbars + (activeLanguage to updated)
            },
            onDismiss = { showCustomizeGuiDialog = false }
        )
    }

    // New File Dialog
    if (showNewFileDialog) {
        AlertDialog(
            onDismissRequest = { showNewFileDialog = false },
            title = { Text("New File in ${project.name}", color = FsTextPrimaryDark) },
            text = {
                Column {
                    Text("Enter filename with extension (e.g. script.py, styles.css, helper.cpp):", color = FsTextSecondaryDark, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newFileNameInput,
                        onValueChange = { newFileNameInput = it },
                        placeholder = { Text("filename.ext", color = FsTextMutedDark) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newFileNameInput.isNotBlank()) {
                            onCreateFile(newFileNameInput.trim(), "")
                            if (!openFileNames.contains(newFileNameInput.trim())) {
                                openFileNames = openFileNames + newFileNameInput.trim()
                            }
                            activeFileName = newFileNameInput.trim()
                            newFileNameInput = ""
                            showNewFileDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1705))
                ) {
                    Text("Create", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFileDialog = false }) {
                    Text("Cancel", color = FsTextSecondaryDark)
                }
            },
            containerColor = FsSurfaceVariantDark
        )
    }
}

// Helpers for code formatting, indenting, commenting
private fun formatCode(code: String, language: LanguageType, tabSize: Int): String {
    val indent = " ".repeat(tabSize)
    var currentIndent = 0
    val formatted = StringBuilder()

    for (rawLine in code.lines()) {
        val trimmed = rawLine.trim()
        if (trimmed.isEmpty()) {
            formatted.append("\n")
            continue
        }

        // Adjust closing indent
        if (trimmed.startsWith("}") || trimmed.startsWith("]") || trimmed.startsWith(")")) {
            currentIndent = (currentIndent - 1).coerceAtLeast(0)
        }

        formatted.append(indent.repeat(currentIndent)).append(trimmed).append("\n")

        // Adjust opening indent
        if (trimmed.endsWith("{") || trimmed.endsWith(":") || trimmed.endsWith("[") || trimmed.endsWith("(")) {
            currentIndent++
        }
    }
    return formatted.toString().trimEnd()
}

private fun toggleComment(code: String, language: LanguageType): String {
    val prefix = when (language) {
        LanguageType.PYTHON -> "# "
        LanguageType.HTML -> "<!-- "
        else -> "// "
    }
    val lines = code.lines()
    val allCommented = lines.all { it.trim().startsWith(prefix.trim()) }

    return lines.joinToString("\n") { line ->
        if (allCommented) {
            line.replaceFirst(prefix, "")
        } else {
            "$prefix$line"
        }
    }
}

private fun indentText(code: String, tabSize: Int): String {
    val spaces = " ".repeat(tabSize)
    return code.lines().joinToString("\n") { "$spaces$it" }
}

private fun dedentText(code: String, tabSize: Int): String {
    val spaces = " ".repeat(tabSize)
    return code.lines().joinToString("\n") { line ->
        if (line.startsWith(spaces)) line.substring(tabSize) else line.trimStart()
    }
}
