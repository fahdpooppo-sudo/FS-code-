package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.ProjectFile
import com.example.ui.theme.*

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebPreviewView(
    activeFile: ProjectFile,
    allFiles: List<ProjectFile>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isMobileViewport by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var refreshKey by remember { mutableIntStateOf(0) }

    // Bundle HTML with CSS and JS if linked or in project
    val fullHtml = remember(activeFile.content, allFiles, refreshKey) {
        bundleHtmlProject(activeFile, allFiles)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FsBackgroundDark)
    ) {
        // Preview Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(FsSurfaceDark)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Language,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Live Web Preview (${activeFile.name})",
                color = FsTextPrimaryDark,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.weight(1f))

            // Toggle Mobile / Fullscreen viewport
            IconButton(
                onClick = { isMobileViewport = !isMobileViewport },
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = if (isMobileViewport) Icons.Default.Smartphone else Icons.Default.Laptop,
                    contentDescription = "Toggle Viewport",
                    tint = if (isMobileViewport) GoldPrimary else FsTextSecondaryDark,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Refresh button
            IconButton(
                onClick = {
                    refreshKey++
                    webViewRef?.reload()
                },
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh Preview",
                    tint = FsTextSecondaryDark,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        HorizontalDivider(color = FsBorderDark, thickness = 1.dp)

        // Webview container
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(FsBackgroundDark),
            contentAlignment = Alignment.TopCenter
        ) {
            val previewModifier = if (isMobileViewport) {
                Modifier
                    .width(375.dp)
                    .fillMaxHeight()
                    .padding(vertical = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp))
            } else {
                Modifier.fillMaxSize()
            }

            AndroidView(
                modifier = previewModifier,
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        webViewClient = WebViewClient()
                        webChromeClient = WebChromeClient()
                        webViewRef = this
                        loadDataWithBaseURL("https://localhost/", fullHtml, "text/html", "UTF-8", null)
                    }
                },
                update = { webView ->
                    webView.loadDataWithBaseURL("https://localhost/", fullHtml, "text/html", "UTF-8", null)
                }
            )
        }
    }
}

private fun bundleHtmlProject(activeFile: ProjectFile, allFiles: List<ProjectFile>): String {
    var html = activeFile.content

    // If active file is not HTML, wrap it or find index.html
    if (!activeFile.name.endsWith(".html")) {
        val indexHtml = allFiles.firstOrNull { it.name.endsWith(".html") }
        if (indexHtml != null) {
            html = indexHtml.content
        } else {
            return "<html><body style='background:#121316;color:#EDEFEF;font-family:sans-serif;padding:20px;'>" +
                    "<h2>FS Code Live View</h2><p>Please open or create an .html file to preview web layouts.</p></body></html>"
        }
    }

    // Inline CSS files
    val cssFiles = allFiles.filter { it.name.endsWith(".css") }
    if (cssFiles.isNotEmpty()) {
        val cssBlock = buildString {
            append("<style>\n")
            cssFiles.forEach { css ->
                append("/* ${css.name} */\n")
                append(css.content).append("\n")
            }
            append("</style>\n")
        }
        html = if (html.contains("</head>")) {
            html.replace("</head>", "$cssBlock</head>")
        } else {
            "$cssBlock$html"
        }
    }

    // Inline JS files
    val jsFiles = allFiles.filter { it.name.endsWith(".js") }
    if (jsFiles.isNotEmpty()) {
        val jsBlock = buildString {
            append("<script>\n")
            jsFiles.forEach { js ->
                append("// ${js.name}\n")
                append(js.content).append("\n")
            }
            append("</script>\n")
        }
        html = if (html.contains("</body>")) {
            html.replace("</body>", "$jsBlock</body>")
        } else {
            "$html$jsBlock"
        }
    }

    return html
}
