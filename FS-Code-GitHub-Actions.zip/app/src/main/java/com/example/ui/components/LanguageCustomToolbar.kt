package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LanguageToolButton
import com.example.model.LanguageType
import com.example.model.ToolActionType
import com.example.ui.theme.*

@Composable
fun LanguageCustomToolbar(
    language: LanguageType,
    buttons: List<LanguageToolButton>,
    isRunning: Boolean = false,
    onActionClick: (ToolActionType, String) -> Unit,
    onCustomizeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(FsSurfaceDark)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Language badge
        Surface(
            color = Color(language.badgeColorHex).copy(alpha = 0.2f),
            shape = RoundedCornerShape(6.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(language.badgeColorHex).copy(alpha = 0.6f)),
            modifier = Modifier.padding(end = 8.dp)
        ) {
            Text(
                text = language.displayName,
                color = Color(language.badgeColorHex),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
            )
        }

        // Custom action buttons scrollable row
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            buttons.filter { it.isEnabled }.forEach { btn ->
                val isPrimaryRun = btn.actionType in listOf(
                    ToolActionType.RUN_MAIN,
                    ToolActionType.RUN_IN_BROWSER,
                    ToolActionType.COMPILE_CONSOLE,
                    ToolActionType.WEB_PREVIEW
                )

                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable(enabled = !isRunning) {
                            onActionClick(btn.actionType, btn.snippetTemplate)
                        },
                    color = if (isPrimaryRun) GoldPrimary else FsSurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isPrimaryRun) GoldDark else FsBorderDark
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        val icon = getIconForName(btn.iconName)
                        Icon(
                            imageVector = icon,
                            contentDescription = btn.title,
                            tint = if (isPrimaryRun) Color(0xFF1E1705) else GoldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = btn.title.substringBefore(" ("),
                            color = if (isPrimaryRun) Color(0xFF1E1705) else FsTextPrimaryDark,
                            fontSize = 12.sp,
                            fontWeight = if (isPrimaryRun) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Customize button
        IconButton(
            onClick = onCustomizeClick,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Tune,
                contentDescription = "Customize Toolbar",
                tint = GoldPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

private fun getIconForName(name: String): ImageVector {
    return when (name) {
        "play_arrow" -> Icons.Default.PlayArrow
        "open_in_browser" -> Icons.Default.OpenInBrowser
        "memory" -> Icons.Default.Memory
        "preview" -> Icons.Default.Visibility
        "auto_fix_high" -> Icons.Default.AutoFixHigh
        "format_indent_increase" -> Icons.Default.FormatIndentIncrease
        "format_indent_decrease" -> Icons.Default.FormatIndentDecrease
        "comment" -> Icons.Default.Comment
        "code" -> Icons.Default.Code
        "crop_square" -> Icons.Default.CropSquare
        "terminal" -> Icons.Default.Terminal
        "arrow_forward" -> Icons.Default.ArrowForward
        else -> Icons.Default.Build
    }
}
