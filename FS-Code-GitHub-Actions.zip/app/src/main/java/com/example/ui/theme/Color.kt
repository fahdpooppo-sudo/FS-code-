package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FS Code Signature Color Palette (Dark Charcoal & Subtle Gold)
val GoldPrimary = Color(0xFFE5C07B)
val GoldDark = Color(0xFFC9A24D)
val GoldLight = Color(0xFFFFDF9E)
val GoldGlow = Color(0x33E5C07B)
val GoldContainer = Color(0xFF2B2516)
val OnGoldContainer = Color(0xFFFFE6A8)

// Professional Dark Surfaces
val FsBackgroundDark = Color(0xFF0D0E12)
val FsSurfaceDark = Color(0xFF15171E)
val FsSurfaceVariantDark = Color(0xFF1E212B)
val FsCardDark = Color(0xFF181A22)
val FsBorderDark = Color(0xFF282C3A)
val FsDividerDark = Color(0xFF222633)

// Text Colors (Dark)
val FsTextPrimaryDark = Color(0xFFEDEFEF)
val FsTextSecondaryDark = Color(0xFF9AA0AC)
val FsTextMutedDark = Color(0xFF636A7A)

// Professional Light Surfaces (when switched)
val FsBackgroundLight = Color(0xFFF6F8FA)
val FsSurfaceLight = Color(0xFFFFFFFF)
val FsSurfaceVariantLight = Color(0xFFEDEDF2)
val FsCardLight = Color(0xFFFFFFFF)
val FsBorderLight = Color(0xFFD0D7DE)
val FsTextPrimaryLight = Color(0xFF1F2328)
val FsTextSecondaryLight = Color(0xFF656D76)

// Syntax Highlighting Colors
val SyntaxKeyword = Color(0xFFC678DD)      // Purple (def, class, function, if, return)
val SyntaxFunction = Color(0xFF61AFEF)     // Blue (print, console.log, main)
val SyntaxString = Color(0xFF98C379)       // Green ("hello", 'world')
val SyntaxNumber = Color(0xFFD19A66)       // Orange (123, 3.14)
val SyntaxComment = Color(0xFF5C6370)      // Gray (# comment, // comment)
val SyntaxType = Color(0xFFE5C07B)         // Gold (int, str, boolean, Promise)
val SyntaxOperator = Color(0xFF56B6C2)     // Cyan (+, -, *, =, =>)
val SyntaxTag = Color(0xFFE06C75)          // Red/Coral (<div>, <html>)
val SyntaxAttribute = Color(0xFFD19A66)    // Orange (class="", id="")

// Status & Indicators
val StatusSuccess = Color(0xFF49C174)
val StatusWarning = Color(0xFFE5C07B)
val StatusError = Color(0xFFE06C75)
val StatusInfo = Color(0xFF61AFEF)
