package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.localization.AppLocale
import com.example.model.AppLanguage
import com.example.model.SettingsState
import com.example.ui.theme.*

@Composable
fun SettingsDialog(
    settings: SettingsState,
    onSettingsChanged: (SettingsState) -> Unit,
    onDismiss: () -> Unit
) {
    var state by remember { mutableStateOf(settings) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = FsSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(GoldContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = AppLocale.get("settings_title", state.language),
                            color = FsTextPrimaryDark,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "FS Code Developer Preferences",
                            color = GoldPrimary,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Language Selection (Arabic, Turkish, English)
                Text(
                    text = AppLocale.get("language_section", state.language),
                    color = FsTextSecondaryDark,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        val isSelected = state.language == lang
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    state = state.copy(language = lang)
                                    onSettingsChanged(state)
                                },
                            color = if (isSelected) GoldContainer else FsCardDark,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) GoldPrimary else FsBorderDark
                            )
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = lang.displayName,
                                    color = if (isSelected) OnGoldContainer else FsTextPrimaryDark,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Strict Commands Language Notice Card
                Surface(
                    color = Color(0xFF1E212B),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier
                                .size(18.dp)
                                .padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppLocale.get("commands_language_notice", state.language),
                            color = FsTextPrimaryDark,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = FsBorderDark, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Dark Mode (Default Enabled)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = AppLocale.get("dark_mode", state.language),
                            color = FsTextPrimaryDark,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Black charcoal & subtle gold aesthetics",
                            color = FsTextSecondaryDark,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = state.isDarkMode,
                        onCheckedChange = {
                            state = state.copy(isDarkMode = it)
                            onSettingsChanged(state)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF1E1705),
                            checkedTrackColor = GoldPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Font Size Slider
                Text(
                    text = "${AppLocale.get("editor_font_size", state.language)}: ${state.editorFontSize}sp",
                    color = FsTextPrimaryDark,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = state.editorFontSize.toFloat(),
                    onValueChange = {
                        state = state.copy(editorFontSize = it.toInt())
                        onSettingsChanged(state)
                    },
                    valueRange = 11f..24f,
                    steps = 12,
                    colors = SliderDefaults.colors(
                        thumbColor = GoldPrimary,
                        activeTrackColor = GoldPrimary,
                        inactiveTrackColor = FsBorderDark
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Tab Size selector (2, 4, 8)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppLocale.get("tab_size", state.language),
                        color = FsTextPrimaryDark,
                        fontSize = 13.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(2, 4, 8).forEach { size ->
                            val isSelected = state.tabSize == size
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable {
                                        state = state.copy(tabSize = size)
                                        onSettingsChanged(state)
                                    },
                                color = if (isSelected) GoldPrimary else FsCardDark,
                                border = androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark)
                            ) {
                                Text(
                                    text = "$size",
                                    color = if (isSelected) Color(0xFF1E1705) else FsTextPrimaryDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Line Numbers switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppLocale.get("line_numbers", state.language),
                        color = FsTextPrimaryDark,
                        fontSize = 13.sp
                    )
                    Switch(
                        checked = state.showLineNumbers,
                        onCheckedChange = {
                            state = state.copy(showLineNumbers = it)
                            onSettingsChanged(state)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF1E1705),
                            checkedTrackColor = GoldPrimary
                        )
                    )
                }

                // Word wrap switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppLocale.get("word_wrap", state.language),
                        color = FsTextPrimaryDark,
                        fontSize = 13.sp
                    )
                    Switch(
                        checked = state.wordWrap,
                        onCheckedChange = {
                            state = state.copy(wordWrap = it)
                            onSettingsChanged(state)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF1E1705),
                            checkedTrackColor = GoldPrimary
                        )
                    )
                }

                // Auto save switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppLocale.get("auto_save", state.language),
                        color = FsTextPrimaryDark,
                        fontSize = 13.sp
                    )
                    Switch(
                        checked = state.autoSave,
                        onCheckedChange = {
                            state = state.copy(autoSave = it)
                            onSettingsChanged(state)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF1E1705),
                            checkedTrackColor = GoldPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Done button
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldPrimary,
                        contentColor = Color(0xFF1E1705)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("OK / حفظ", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
