package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.DefaultExtensions
import com.example.model.ExtensionItem
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtensionsSheet(
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit
) {
    var extensions by remember { mutableStateOf(DefaultExtensions.getList()) }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Language", "Runtime", "Compiler", "Theme")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = FsSurfaceDark,
        dragHandle = {
            BottomSheetDefaults.DragHandle(color = GoldPrimary.copy(alpha = 0.5f))
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(GoldContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Extension,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = if (currentLanguage == AppLanguage.ARABIC) "متجر الإضافات البرمجية" else if (currentLanguage == AppLanguage.TURKISH) "Eklenti Mağazası" else "Extensions & Plugins Marketplace",
                        color = FsTextPrimaryDark,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "FS Code Developer Ecosystem",
                        color = GoldPrimary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Category filter chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSelected = cat == selectedCategory
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldPrimary,
                            selectedLabelColor = Color(0xFF1E1705),
                            containerColor = FsCardDark,
                            labelColor = FsTextSecondaryDark
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = if (isSelected) GoldPrimary else FsBorderDark,
                            enabled = true,
                            selected = isSelected
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Extensions list
            val filtered = if (selectedCategory == "All") extensions else extensions.filter { it.category == selectedCategory }

            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.id }) { ext ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = FsCardDark,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF212532)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Code,
                                    contentDescription = null,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ext.name,
                                    color = FsTextPrimaryDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )

                                val desc = when (currentLanguage) {
                                    AppLanguage.ARABIC -> ext.descriptionAr
                                    AppLanguage.TURKISH -> ext.descriptionTr
                                    AppLanguage.ENGLISH -> ext.descriptionEn
                                }
                                Text(
                                    text = desc,
                                    color = FsTextSecondaryDark,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp,
                                    maxLines = 2
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "★ ${ext.rating}",
                                        color = GoldPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "↓ ${ext.downloads}",
                                        color = FsTextMutedDark,
                                        fontSize = 10.sp
                                    )
                                    Text(
                                        text = "v${ext.version}",
                                        color = FsTextMutedDark,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Switch(
                                checked = ext.isInstalled && ext.isEnabled,
                                onCheckedChange = { isChecked ->
                                    extensions = extensions.map {
                                        if (it.id == ext.id) it.copy(isInstalled = isChecked, isEnabled = isChecked) else it
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color(0xFF1E1705),
                                    checkedTrackColor = GoldPrimary,
                                    uncheckedThumbColor = FsTextMutedDark,
                                    uncheckedTrackColor = Color(0xFF282C3A)
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
