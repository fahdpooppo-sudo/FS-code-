package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.LanguageToolButton
import com.example.model.LanguageType
import com.example.model.ToolActionType
import com.example.ui.theme.*

@Composable
fun CustomizeLanguageGuiDialog(
    language: LanguageType,
    currentButtons: List<LanguageToolButton>,
    onSaveButtons: (List<LanguageToolButton>) -> Unit,
    onDismiss: () -> Unit
) {
    var buttons by remember { mutableStateOf(currentButtons) }
    var newSnippetTitle by remember { mutableStateOf("") }
    var newSnippetCode by remember { mutableStateOf("") }
    var showAddSnippet by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = FsSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "تخصيص واجهة ${language.displayName}",
                            color = FsTextPrimaryDark,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "تخصيص أزرار الأدوات والاختصارات السريعة",
                            color = GoldPrimary,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // List of buttons
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(buttons, key = { it.id }) { btn ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = FsCardDark,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, FsBorderDark)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = btn.title,
                                    color = if (btn.isEnabled) FsTextPrimaryDark else FsTextMutedDark,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f)
                                )

                                Switch(
                                    checked = btn.isEnabled,
                                    onCheckedChange = { isChecked ->
                                        buttons = buttons.map {
                                            if (it.id == btn.id) it.copy(isEnabled = isChecked) else it
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color(0xFF1E1705),
                                        checkedTrackColor = GoldPrimary
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Add Custom Snippet button
                if (!showAddSnippet) {
                    OutlinedButton(
                        onClick = { showAddSnippet = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة زر اختصار مخصص (Custom Snippet)", fontSize = 12.sp)
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(FsSurfaceVariantDark, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        OutlinedTextField(
                            value = newSnippetTitle,
                            onValueChange = { newSnippetTitle = it },
                            placeholder = { Text("عنوان الزر (مثلاً: lambda)", fontSize = 11.sp, color = FsTextMutedDark) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = newSnippetCode,
                            onValueChange = { newSnippetCode = it },
                            placeholder = { Text("الكود الذي سيتم إدراجه", fontSize = 11.sp, color = FsTextMutedDark) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showAddSnippet = false }) {
                                Text("إلغاء", color = FsTextSecondaryDark, fontSize = 11.sp)
                            }
                            Button(
                                onClick = {
                                    if (newSnippetTitle.isNotBlank()) {
                                        val newBtn = LanguageToolButton(
                                            id = "custom_" + System.currentTimeMillis(),
                                            title = newSnippetTitle,
                                            actionType = ToolActionType.INSERT_SNIPPET,
                                            iconName = "code",
                                            isEnabled = true,
                                            snippetTemplate = newSnippetCode
                                        )
                                        buttons = buttons + newBtn
                                        newSnippetTitle = ""
                                        newSnippetCode = ""
                                        showAddSnippet = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GoldPrimary,
                                    contentColor = Color(0xFF1E1705)
                                )
                            ) {
                                Text("إضافة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("إلغاء", color = FsTextSecondaryDark)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onSaveButtons(buttons)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color(0xFF1E1705)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("حفظ التخصيص", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
