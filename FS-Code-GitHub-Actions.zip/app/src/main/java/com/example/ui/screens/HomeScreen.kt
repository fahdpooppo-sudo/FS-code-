package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.localization.AppLocale
import com.example.model.*
import com.example.ui.dialogs.ExtensionsSheet
import com.example.ui.dialogs.LinkedAppsSheet
import com.example.ui.dialogs.NewProjectDialog
import com.example.ui.dialogs.SettingsDialog
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    projects: List<Project>,
    settings: SettingsState,
    onOpenProject: (Project) -> Unit,
    onCreateProject: (name: String, template: ProjectTemplate, description: String) -> Unit,
    onDeleteProject: (String) -> Unit,
    onExportZip: (String) -> Unit,
    onSettingsChanged: (SettingsState) -> Unit,
    onOpenFsBuilder: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") }

    var showNewProjectDialog by remember { mutableStateOf(false) }
    var showLinkedAppsSheet by remember { mutableStateOf(false) }
    var showExtensionsSheet by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var projectToDelete by remember { mutableStateOf<Project?>(null) }

    val filterOptions = listOf(
        "ALL" to "الكل (All)",
        "PYTHON" to "Python",
        "WEB" to "Web (HTML/JS)",
        "CPP" to "C++"
    )

    val filteredProjects = projects.filter { proj ->
        val matchesSearch = proj.name.contains(searchQuery, ignoreCase = true) ||
                proj.description.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (selectedFilter) {
            "PYTHON" -> proj.primaryLanguage == LanguageType.PYTHON
            "WEB" -> proj.primaryLanguage in listOf(LanguageType.HTML, LanguageType.JAVASCRIPT)
            "CPP" -> proj.primaryLanguage == LanguageType.CPP
            else -> true
        }
        matchesSearch && matchesFilter
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = FsBackgroundDark,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(FsSurfaceDark)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Top header row with branding
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(GoldPrimary, Color(0xFFC9A24D))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = "FS Code Logo",
                            tint = Color(0xFF1E1705),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "FS CODE",
                                color = FsTextPrimaryDark,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = GoldContainer,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(0.5.dp, GoldPrimary.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = "f-Studio",
                                    color = GoldPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = AppLocale.get("app_subtitle", settings.language),
                            color = FsTextSecondaryDark,
                            fontSize = 11.sp
                        )
                    }

                    // Settings Button
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier
                            .size(38.dp)
                            .background(FsSurfaceVariantDark, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "بحث في المشاريع (Search projects)...",
                            color = FsTextMutedDark,
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = FsTextSecondaryDark,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = FsTextSecondaryDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = FsBorderDark,
                        focusedTextColor = FsTextPrimaryDark,
                        unfocusedTextColor = FsTextPrimaryDark,
                        focusedContainerColor = FsBackgroundDark,
                        unfocusedContainerColor = FsBackgroundDark
                    ),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            }
        },
        bottomBar = {
            // Bottom Action Bar: Linked Apps on Left, Extensions on Right
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                color = FsSurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Bottom-Left: Linked Apps (FS Builder)
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { showLinkedAppsSheet = true },
                        color = Color(0xFF1B1E28),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hub,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = if (settings.language == AppLanguage.ARABIC) "التطبيقات المرتبطة" else if (settings.language == AppLanguage.TURKISH) "Bağlı Uygulamalar" else "Linked Apps",
                                    color = FsTextPrimaryDark,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "FS Builder",
                                    color = GoldPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Bottom-Right: Extensions
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { showExtensionsSheet = true },
                        color = Color(0xFF1B1E28),
                        border = androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Extension,
                                contentDescription = null,
                                tint = SyntaxOperator,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = AppLocale.get("extensions_btn", settings.language),
                                    color = FsTextPrimaryDark,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Marketplace",
                                    color = SyntaxOperator,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))

                // LARGE PROMINENT "NEW PROJECT" CARD
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { showNewProjectDialog = true },
                    color = GoldContainer,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary)
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GoldPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PostAdd,
                                    contentDescription = null,
                                    tint = Color(0xFF1E1705),
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppLocale.get("new_project_btn", settings.language),
                                    color = OnGoldContainer,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = AppLocale.get("new_project_desc", settings.language),
                                    color = FsTextPrimaryDark.copy(alpha = 0.85f),
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.ArrowForwardIos,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Category filter chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filterOptions) { (key, label) ->
                        val isSelected = selectedFilter == key
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedFilter = key },
                            label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldPrimary,
                                selectedLabelColor = Color(0xFF1E1705),
                                containerColor = FsSurfaceVariantDark,
                                labelColor = FsTextPrimaryDark
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                borderColor = if (isSelected) GoldPrimary else FsBorderDark,
                                enabled = true,
                                selected = isSelected
                            )
                        )
                    }
                }
            }

            // Projects List Title
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppLocale.get("projects_title", settings.language),
                        color = FsTextPrimaryDark,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${filteredProjects.size} Projects",
                        color = GoldPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Projects Cards
            if (filteredProjects.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                tint = FsTextMutedDark,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No projects found",
                                color = FsTextSecondaryDark,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            } else {
                items(filteredProjects, key = { it.id }) { project ->
                    ProjectCard(
                        project = project,
                        settings = settings,
                        onOpen = { onOpenProject(project) },
                        onDelete = { projectToDelete = project },
                        onExport = { onExportZip(project.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // New Project Dialog
    if (showNewProjectDialog) {
        NewProjectDialog(
            currentLanguage = settings.language,
            onDismiss = { showNewProjectDialog = false },
            onCreateProject = { name, template, desc ->
                onCreateProject(name, template, desc)
            }
        )
    }

    // Linked Apps Sheet (FS Builder)
    if (showLinkedAppsSheet) {
        LinkedAppsSheet(
            currentLanguage = settings.language,
            onOpenFsBuilder = {
                showLinkedAppsSheet = false
                onOpenFsBuilder()
            },
            onOpenTerminal = {
                showLinkedAppsSheet = false
                if (projects.isNotEmpty()) {
                    onOpenProject(projects.first())
                }
            },
            onDismiss = { showLinkedAppsSheet = false }
        )
    }

    // Extensions Sheet
    if (showExtensionsSheet) {
        ExtensionsSheet(
            currentLanguage = settings.language,
            onDismiss = { showExtensionsSheet = false }
        )
    }

    // Settings Dialog
    if (showSettingsDialog) {
        SettingsDialog(
            settings = settings,
            onSettingsChanged = onSettingsChanged,
            onDismiss = { showSettingsDialog = false }
        )
    }

    // Delete Project Confirmation Dialog
    if (projectToDelete != null) {
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            title = {
                Text(
                    text = AppLocale.get("delete_project_confirm", settings.language),
                    color = FsTextPrimaryDark
                )
            },
            text = {
                Text(
                    text = "Project '${projectToDelete?.name}' will be permanently removed from disk.",
                    color = FsTextSecondaryDark
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        projectToDelete?.let { onDeleteProject(it.id) }
                        projectToDelete = null
                    }
                ) {
                    Text(text = AppLocale.get("delete", settings.language), color = StatusError)
                }
            },
            dismissButton = {
                TextButton(onClick = { projectToDelete = null }) {
                    Text(text = AppLocale.get("cancel", settings.language), color = FsTextSecondaryDark)
                }
            },
            containerColor = FsSurfaceVariantDark
        )
    }
}

@Composable
private fun ProjectCard(
    project: Project,
    settings: SettingsState,
    onOpen: () -> Unit,
    onDelete: () -> Unit,
    onExport: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onOpen() },
        color = FsCardDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Language badge
                Surface(
                    color = Color(project.primaryLanguage.badgeColorHex).copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        Color(project.primaryLanguage.badgeColorHex).copy(alpha = 0.7f)
                    )
                ) {
                    Text(
                        text = project.primaryLanguage.displayName,
                        color = Color(project.primaryLanguage.badgeColorHex),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = project.name,
                    color = FsTextPrimaryDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )

                // Menu options
                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Options",
                            tint = FsTextSecondaryDark,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(FsSurfaceVariantDark)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Open Project", color = FsTextPrimaryDark) },
                            onClick = {
                                showMenu = false
                                onOpen()
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Code, contentDescription = null, tint = GoldPrimary)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Export as ZIP", color = FsTextPrimaryDark) },
                            onClick = {
                                showMenu = false
                                onExport()
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Archive, contentDescription = null, tint = FsTextSecondaryDark)
                            }
                        )
                        HorizontalDivider(color = FsBorderDark)
                        DropdownMenuItem(
                            text = { Text("Delete Project", color = StatusError) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            },
                            leadingIcon = {
                                Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = StatusError)
                            }
                        )
                    }
                }
            }

            if (project.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = project.description,
                    color = FsTextSecondaryDark,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer metadata
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "${project.filesCount} files",
                        color = FsTextMutedDark,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "•",
                        color = FsTextMutedDark,
                        fontSize = 11.sp
                    )
                    Text(
                        text = dateFormat.format(Date(project.updatedAt)),
                        color = FsTextMutedDark,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    color = GoldContainer,
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
                    modifier = Modifier.clickable { onOpen() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Open",
                            color = OnGoldContainer,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
