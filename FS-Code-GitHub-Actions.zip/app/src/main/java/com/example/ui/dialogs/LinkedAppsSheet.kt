package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.DefaultLinkedApps
import com.example.model.LinkedApp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LinkedAppsSheet(
    currentLanguage: AppLanguage,
    onOpenFsBuilder: () -> Unit,
    onOpenTerminal: () -> Unit,
    onDismiss: () -> Unit
) {
    val apps = DefaultLinkedApps.getList()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = FsSurfaceDark,
        dragHandle = {
            BottomSheetDefaults.DragHandle(color = GoldPrimary.copy(alpha = 0.5f))
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(GoldContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Hub,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = if (currentLanguage == AppLanguage.ARABIC) "التطبيقات المرتبطة (منظومة FS)" else if (currentLanguage == AppLanguage.TURKISH) "Bağlı Uygulamalar (FS Ekosistemi)" else "Linked Applications (FS Ecosystem)",
                        color = FsTextPrimaryDark,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "f-Studio Developer Suite Integration",
                        color = GoldPrimary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Info Card about FS Builder
            Surface(
                color = Color(0xFF1E212B),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.ARABIC)
                            "تطبيق FS Code متصل مباشرة مع FS Builder لتصميم واجهات التطبيقات وتوليد الأكواد بسلاسة."
                        else if (currentLanguage == AppLanguage.TURKISH)
                            "FS Code, arayüz tasarlamak ve kod üretmek için doğrudan FS Builder ile entegre çalışır."
                        else
                            "FS Code is natively linked with FS Builder for visual UI design and code generation.",
                        color = FsTextPrimaryDark,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Apps List
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(apps, key = { it.id }) { app ->
                    val isFsBuilder = app.id == "fs_builder"
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                if (app.id == "fs_builder") {
                                    onDismiss()
                                    onOpenFsBuilder()
                                } else if (app.id == "fs_terminal") {
                                    onDismiss()
                                    onOpenTerminal()
                                }
                            },
                        color = if (isFsBuilder) GoldContainer else FsCardDark,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isFsBuilder) GoldPrimary else FsBorderDark
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val icon = getAppIcon(app.iconKey)
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isFsBuilder) GoldPrimary else FsTextSecondaryDark,
                                modifier = Modifier.size(26.dp)
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = app.name,
                                        color = if (isFsBuilder) OnGoldContainer else FsTextPrimaryDark,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        color = if (isFsBuilder) GoldPrimary else Color(0xFF282C3A),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = app.badge,
                                            color = if (isFsBuilder) Color(0xFF1E1705) else FsTextSecondaryDark,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                val desc = when (currentLanguage) {
                                    AppLanguage.ARABIC -> app.descriptionAr
                                    AppLanguage.TURKISH -> app.descriptionTr
                                    AppLanguage.ENGLISH -> app.descriptionEn
                                }
                                Text(
                                    text = desc,
                                    color = FsTextSecondaryDark,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }

                            Surface(
                                color = if (isFsBuilder) StatusSuccess.copy(alpha = 0.2f) else Color(0xFF232733),
                                shape = RoundedCornerShape(6.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    0.5.dp,
                                    if (isFsBuilder) StatusSuccess else FsBorderDark
                                )
                            ) {
                                Text(
                                    text = if (isFsBuilder) "متصل" else app.status,
                                    color = if (isFsBuilder) StatusSuccess else FsTextSecondaryDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

private fun getAppIcon(key: String): ImageVector {
    return when (key) {
        "widgets" -> Icons.Default.Widgets
        "account" -> Icons.Default.AccountCircle
        "cloud" -> Icons.Default.CloudQueue
        "terminal" -> Icons.Default.Terminal
        else -> Icons.Default.Apps
    }
}
