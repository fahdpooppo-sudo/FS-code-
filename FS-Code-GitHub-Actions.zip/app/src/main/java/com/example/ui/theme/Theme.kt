package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color(0xFF1E1705),
    primaryContainer = GoldContainer,
    onPrimaryContainer = OnGoldContainer,
    secondary = GoldDark,
    onSecondary = Color(0xFF1E1705),
    secondaryContainer = FsSurfaceVariantDark,
    onSecondaryContainer = GoldLight,
    tertiary = SyntaxOperator,
    onTertiary = Color.Black,
    background = FsBackgroundDark,
    onBackground = FsTextPrimaryDark,
    surface = FsSurfaceDark,
    onSurface = FsTextPrimaryDark,
    surfaceVariant = FsSurfaceVariantDark,
    onSurfaceVariant = FsTextSecondaryDark,
    outline = FsBorderDark,
    outlineVariant = FsDividerDark
)

private val LightColorScheme = lightColorScheme(
    primary = GoldDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFF3D4),
    onPrimaryContainer = Color(0xFF382900),
    secondary = Color(0xFF5A5242),
    onSecondary = Color.White,
    secondaryContainer = FsSurfaceVariantLight,
    onSecondaryContainer = Color(0xFF1E1C16),
    tertiary = Color(0xFF006876),
    onTertiary = Color.White,
    background = FsBackgroundLight,
    onBackground = FsTextPrimaryLight,
    surface = FsSurfaceLight,
    onSurface = FsTextPrimaryLight,
    surfaceVariant = FsSurfaceVariantLight,
    onSurfaceVariant = FsTextSecondaryLight,
    outline = FsBorderLight,
    outlineVariant = Color(0xFFE2E4E8)
)

@Composable
fun MyApplicationTheme(
    // Default to darkTheme = true as requested by user prompt
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Preserve FS Code gold brand aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
