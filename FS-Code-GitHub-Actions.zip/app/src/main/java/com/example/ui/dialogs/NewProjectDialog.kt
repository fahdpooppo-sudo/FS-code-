package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AppLanguage
import com.example.model.ProjectTemplate
import com.example.ui.theme.*

@Composable
fun NewProjectDialog(
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onCreateProject: (name: String, template: ProjectTemplate, description: String) -> Unit
) {
    var projectName by remember { mutableStateOf("") }
    var projectDescription by remember { mutableStateOf("") }
    var selectedTemplate by remember { mutableStateOf(ProjectTemplate.PYTHON_APP) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = FsSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, FsBorderDark),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(GoldContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CreateNewFolder,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = if (currentLanguage == AppLanguage.ARABIC) "إنشاء مشروع جديد" else if (currentLanguage == AppLanguage.TURKISH) "Yeni Proje Oluştur" else "Create New Project",
                            color = FsTextPrimaryDark,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "FS Code Developer Studio",
                            color = GoldPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Project Name Field
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    label = { Text("Project Name", color = FsTextSecondaryDark) },
                    placeholder = { Text("e.g. MyPythonApp or WebStore", color = FsTextMutedDark) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = FsBorderDark,
                        focusedTextColor = FsTextPrimaryDark,
                        unfocusedTextColor = FsTextPrimaryDark
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Template selection title
                Text(
                    text = if (currentLanguage == AppLanguage.ARABIC) "اختر بيئة التشغيل والقالب:" else if (currentLanguage == AppLanguage.TURKISH) "Çalışma Ortamı ve Şablonu Seçin:" else "Select Runtime Template:",
                    color = FsTextSecondaryDark,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Template options
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProjectTemplate.entries.forEach { template ->
                        val isSelected = template == selectedTemplate
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { selectedTemplate = template },
                            color = if (isSelected) GoldContainer else FsCardDark,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) GoldPrimary else FsBorderDark
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val icon = getTemplateIcon(template.iconName)
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) GoldPrimary else FsTextSecondaryDark,
                                    modifier = Modifier.size(24.dp)
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    val title = when (currentLanguage) {
                                        AppLanguage.ARABIC -> template.titleAr
                                        AppLanguage.TURKISH -> template.titleTr
                                        AppLanguage.ENGLISH -> template.titleEn
                                    }
                                    val desc = when (currentLanguage) {
                                        AppLanguage.ARABIC -> template.descriptionAr
                                        else -> template.descriptionEn
                                    }
                                    Text(
                                        text = title,
                                        color = if (isSelected) OnGoldContainer else FsTextPrimaryDark,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = desc,
                                        color = FsTextSecondaryDark,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                }

                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedTemplate = template },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = GoldPrimary,
                                        unselectedColor = FsBorderDark
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(
                            text = if (currentLanguage == AppLanguage.ARABIC) "إلغاء" else "Cancel",
                            color = FsTextSecondaryDark
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val finalName = if (projectName.isNotBlank()) projectName.trim() else "${selectedTemplate.primaryLanguage.displayName} Project"
                            onCreateProject(finalName, selectedTemplate, projectDescription)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color(0xFF1E1705)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (currentLanguage == AppLanguage.ARABIC) "إنشاء المشروع" else "Create Project",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

private fun getTemplateIcon(name: String): ImageVector {
    return when (name) {
        "terminal" -> Icons.Default.Terminal
        "globe" -> Icons.Default.Language
        "memory" -> Icons.Default.Memory
        else -> Icons.Default.Folder
    }
}
