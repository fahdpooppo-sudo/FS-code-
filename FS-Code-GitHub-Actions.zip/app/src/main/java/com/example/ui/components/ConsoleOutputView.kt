package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExecutionResult
import com.example.model.ExecutionStatus
import com.example.ui.theme.*

@Composable
fun ConsoleOutputView(
    result: ExecutionResult,
    isRunning: Boolean,
    onClearLogs: () -> Unit,
    onSendStdin: (String) -> Unit,
    onErrorLineClick: ((Int) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var stdinInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Auto scroll to bottom when new logs arrive
    LaunchedEffect(result.logs.size) {
        if (result.logs.isNotEmpty()) {
            listState.animateScrollToItem(result.logs.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FsBackgroundDark)
    ) {
        // Console Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(FsSurfaceDark)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Terminal,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (result.runnerName.isNotEmpty()) result.runnerName else "Console Output",
                color = FsTextPrimaryDark,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            if (result.executionTimeMs > 0) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "(${result.executionTimeMs}ms)",
                    color = FsTextMutedDark,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Status chip
            val statusColor = when (result.status) {
                ExecutionStatus.RUNNING -> GoldPrimary
                ExecutionStatus.SUCCESS -> StatusSuccess
                ExecutionStatus.ERROR -> StatusError
                ExecutionStatus.IDLE -> FsTextMutedDark
            }
            Surface(
                color = statusColor.copy(alpha = 0.15f),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.5f))
            ) {
                Text(
                    text = when (result.status) {
                        ExecutionStatus.RUNNING -> "RUNNING"
                        ExecutionStatus.SUCCESS -> "SUCCESS (0)"
                        ExecutionStatus.ERROR -> "ERROR (${result.exitCode})"
                        ExecutionStatus.IDLE -> "READY"
                    },
                    color = statusColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Copy button
            IconButton(
                onClick = {
                    val fullText = result.logs.joinToString("\n") { it.text }
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Console Output", fullText))
                    Toast.makeText(context, "Output copied to clipboard", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy Output",
                    tint = FsTextSecondaryDark,
                    modifier = Modifier.size(15.dp)
                )
            }

            // Clear button
            IconButton(
                onClick = onClearLogs,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Clear Console",
                    tint = FsTextSecondaryDark,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        HorizontalDivider(color = FsBorderDark, thickness = 1.dp)

        // Terminal Log List
        Box(modifier = Modifier.weight(1f)) {
            if (result.logs.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Terminal idle. Press Run to execute in sandboxed environment.",
                        color = FsTextMutedDark,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    items(result.logs, key = { it.id }) { log ->
                        val textColor = when {
                            log.isError -> StatusError
                            log.isSystem -> GoldPrimary.copy(alpha = 0.85f)
                            else -> FsTextPrimaryDark
                        }

                        val hasErrorLine = log.isError && result.errorLine != null

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(
                                    if (hasErrorLine) {
                                        Modifier.clickable { onErrorLineClick?.invoke(result.errorLine!!) }
                                    } else Modifier
                                )
                                .padding(vertical = 1.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = log.text,
                                color = textColor,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 17.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = FsBorderDark, thickness = 0.5.dp)

        // Interactive STDIN Input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(FsSurfaceDark)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = ">",
                color = GoldPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, end = 8.dp)
            )

            OutlinedTextField(
                value = stdinInput,
                onValueChange = { stdinInput = it },
                placeholder = {
                    Text(
                        text = "Type stdin input (e.g. for input() or cin >>)...",
                        color = FsTextMutedDark,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = FsTextPrimaryDark,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = FsBorderDark,
                    focusedContainerColor = FsBackgroundDark,
                    unfocusedContainerColor = FsBackgroundDark
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(6.dp))

            Button(
                onClick = {
                    if (stdinInput.isNotBlank()) {
                        onSendStdin(stdinInput)
                        stdinInput = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = Color(0xFF1E1705)
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                modifier = Modifier.height(40.dp)
            ) {
                Text("Send", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
