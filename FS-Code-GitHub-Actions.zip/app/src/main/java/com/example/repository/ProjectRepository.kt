package com.example.repository

import android.content.Context
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ProjectRepository(private val context: Context) {

    private val baseDir: File = File(context.filesDir, "fscode_projects").apply {
        if (!exists()) mkdirs()
    }

    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    private val _activeProjectFiles = MutableStateFlow<List<ProjectFile>>(emptyList())
    val activeProjectFiles: StateFlow<List<ProjectFile>> = _activeProjectFiles.asStateFlow()

    suspend fun initialize() = withContext(Dispatchers.IO) {
        loadProjectsFromDisk()
        if (_projects.value.isEmpty()) {
            createSampleProjects()
        }
    }

    private fun loadProjectsFromDisk() {
        val projectDirs = baseDir.listFiles { f -> f.isDirectory } ?: emptyArray()
        val list = mutableListOf<Project>()

        for (dir in projectDirs) {
            val metaFile = File(dir, ".project_meta")
            val filesCount = dir.listFiles { f -> !f.name.startsWith(".") }?.size ?: 0
            if (metaFile.exists()) {
                val lines = metaFile.readLines()
                val id = lines.getOrNull(0) ?: dir.name
                val name = lines.getOrNull(1) ?: dir.name
                val templateId = lines.getOrNull(2) ?: ProjectTemplate.PYTHON_APP.id
                val template = ProjectTemplate.entries.firstOrNull { it.id == templateId } ?: ProjectTemplate.PYTHON_APP
                val desc = lines.getOrNull(3) ?: ""
                val created = lines.getOrNull(4)?.toLongOrNull() ?: dir.lastModified()
                list.add(
                    Project(
                        id = id,
                        name = name,
                        description = desc,
                        template = template,
                        createdAt = created,
                        updatedAt = dir.lastModified(),
                        filesCount = filesCount,
                        primaryLanguage = template.primaryLanguage
                    )
                )
            } else {
                list.add(
                    Project(
                        id = dir.name,
                        name = dir.name,
                        description = "Local FS Code Workspace",
                        template = ProjectTemplate.PYTHON_APP,
                        createdAt = dir.lastModified(),
                        updatedAt = dir.lastModified(),
                        filesCount = filesCount,
                        primaryLanguage = LanguageType.PYTHON
                    )
                )
            }
        }
        _projects.value = list.sortedByDescending { it.updatedAt }
    }

    suspend fun createProject(
        name: String,
        template: ProjectTemplate,
        description: String = ""
    ): Project = withContext(Dispatchers.IO) {
        val projectId = "proj_" + UUID.randomUUID().toString().take(8)
        val projectDir = File(baseDir, projectId).apply { mkdirs() }

        // Write meta
        val metaFile = File(projectDir, ".project_meta")
        metaFile.writeText(
            "$projectId\n$name\n${template.id}\n$description\n${System.currentTimeMillis()}"
        )

        // Seed template files
        when (template) {
            ProjectTemplate.PYTHON_APP -> {
                val mainPy = File(projectDir, "main.py")
                mainPy.writeText(
                    """
# FS Code - Python 3 Sandboxed Application
# Developed with f-Studio Apps ecosystem

import math
import sys

def calculate_stats(numbers):
    total = sum(numbers)
    count = len(numbers)
    mean = total / count if count > 0 else 0
    return mean

def fibonacci(n):
    a, b = 0, 1
    result = []
    for _ in range(n):
        result.append(a)
        a, b = b, a + b
    return result

if __name__ == '__main__':
    print("Welcome to FS Code Python Sandbox!")
    print("Python execution version: 3.11.0")
    
    data = [10, 25, 40, 55, 70, 95]
    avg = calculate_stats(data)
    print(f"Data values: {data}")
    print(f"Computed average: {avg}")
    
    sq = math.sqrt(144)
    print(f"Square root of 144 is: {sq}")
    
    fib_series = fibonacci(8)
    print(f"First 8 Fibonacci numbers: {fib_series}")
    print("Sandbox execution verified successfully.")
                    """.trimIndent()
                )

                val utilsPy = File(projectDir, "utils.py")
                utilsPy.writeText(
                    """
# Utility functions module
def greet(user="Developer"):
    return f"Hello, {user}! Happy coding in FS Code."
                    """.trimIndent()
                )
            }

            ProjectTemplate.WEB_APP -> {
                val htmlFile = File(projectDir, "index.html")
                htmlFile.writeText(
                    """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FS Code Web Project</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="card">
        <div class="badge">f-Studio Apps</div>
        <h1>FS Code Live Web Preview</h1>
        <p>Interactive web sandbox running directly in the browser.</p>
        
        <div class="counter-box">
            <span id="counter-val">0</span>
        </div>
        
        <div class="buttons">
            <button id="btn-inc" class="btn primary">+ Increment</button>
            <button id="btn-reset" class="btn secondary">Reset</button>
        </div>
        
        <div id="log-output" class="console-box">Click a button to execute JavaScript!</div>
    </div>
    
    <script src="app.js"></script>
</body>
</html>
                    """.trimIndent()
                )

                val cssFile = File(projectDir, "style.css")
                cssFile.writeText(
                    """
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}
body {
    background-color: #0D0E12;
    color: #ECEFF4;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 20px;
}
.card {
    background: #181A22;
    border: 1px solid #E5C07B;
    border-radius: 16px;
    padding: 28px;
    max-width: 420px;
    width: 100%;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
}
.badge {
    display: inline-block;
    color: #E5C07B;
    border: 1px solid #E5C07B;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    margin-bottom: 12px;
    font-weight: bold;
}
h1 {
    font-size: 22px;
    margin-bottom: 8px;
}
p {
    font-size: 14px;
    color: #9AA0AC;
    margin-bottom: 24px;
}
.counter-box {
    font-size: 48px;
    font-weight: bold;
    color: #E5C07B;
    margin-bottom: 20px;
}
.buttons {
    display: flex;
    gap: 12px;
    justify-content: center;
    margin-bottom: 20px;
}
.btn {
    padding: 10px 20px;
    border-radius: 8px;
    border: none;
    font-weight: 600;
    cursor: pointer;
}
.btn.primary {
    background: #E5C07B;
    color: #121316;
}
.btn.secondary {
    background: #282C3A;
    color: #ECEFF4;
}
.console-box {
    background: #0D0E12;
    padding: 10px;
    border-radius: 6px;
    font-size: 13px;
    color: #56B6C2;
    font-family: monospace;
}
                    """.trimIndent()
                )

                val jsFile = File(projectDir, "app.js")
                jsFile.writeText(
                    """
// FS Code - JavaScript Runtime in Browser
console.log("FS Code Web runtime initialized");

let count = 0;
const counterVal = document.getElementById("counter-val");
const btnInc = document.getElementById("btn-inc");
const btnReset = document.getElementById("btn-reset");
const logBox = document.getElementById("log-output");

btnInc.addEventListener("click", () => {
    count++;
    counterVal.innerText = count;
    logBox.innerText = "JS Event: Counter incremented to " + count;
    console.log("Counter is now:", count);
});

btnReset.addEventListener("click", () => {
    count = 0;
    counterVal.innerText = count;
    logBox.innerText = "JS Event: Counter reset to 0";
    console.log("Counter reset");
});
                    """.trimIndent()
                )
            }

            ProjectTemplate.CPP_CLI -> {
                val cppFile = File(projectDir, "main.cpp")
                cppFile.writeText(
                    """
// FS Code - C++ Console Application
// Instant compilation & console diagnostics

#include <iostream>
#include <vector>
#include <string>

using namespace std;

void greetDeveloper(const string& name) {
    cout << "Hello, " << name << "! Welcome to FS Code C++ IDE." << endl;
}

int main() {
    cout << "========================================" << endl;
    cout << "FS Code C++ Virtual Compiler (Clang 20)" << endl;
    cout << "========================================" << endl;
    
    greetDeveloper("Engineer");
    
    vector<int> numbers = {12, 45, 68, 91, 104};
    cout << "Processing vector data: size = " << numbers.size() << endl;
    
    int sum = 0;
    for (int num : numbers) {
        sum += num;
    }
    
    cout << "Calculated sum: " << sum << endl;
    cout << "Memory check: OK. Execution completed." << endl;
    
    return 0;
}
                    """.trimIndent()
                )
            }

            ProjectTemplate.EMPTY -> {
                val readme = File(projectDir, "README.md")
                readme.writeText(
                    """
# $name
A clean project workspace created with FS Code by f-Studio Apps.
                    """.trimIndent()
                )
            }
        }

        loadProjectsFromDisk()
        _projects.value.first { it.id == projectId }
    }

    private suspend fun createSampleProjects() {
        createProject(
            name = "Python Analytics Sandbox",
            template = ProjectTemplate.PYTHON_APP,
            description = "Interactive Python algorithms with isolated virtual environment"
        )
        createProject(
            name = "FS Web Application",
            template = ProjectTemplate.WEB_APP,
            description = "Responsive HTML5, modern CSS, and JavaScript browser execution"
        )
        createProject(
            name = "C++ Algorithm Suite",
            template = ProjectTemplate.CPP_CLI,
            description = "Instant C++ compilation, syntax checks, and console outputs"
        )
    }

    suspend fun loadProjectFiles(projectId: String): List<ProjectFile> = withContext(Dispatchers.IO) {
        val dir = File(baseDir, projectId)
        if (!dir.exists()) return@withContext emptyList()

        val files = dir.listFiles { f -> !f.name.startsWith(".") } ?: emptyArray()
        val result = mutableListOf<ProjectFile>()

        for (f in files) {
            val content = if (f.isFile) f.readText() else ""
            result.add(
                ProjectFile(
                    id = f.name,
                    projectId = projectId,
                    name = f.name,
                    relativePath = f.name,
                    content = content,
                    isDirectory = f.isDirectory,
                    language = LanguageType.fromFileName(f.name),
                    lastSavedTimestamp = f.lastModified()
                )
            )
        }
        val sorted = result.sortedWith(compareBy({ !it.isDirectory }, { it.name }))
        _activeProjectFiles.value = sorted
        sorted
    }

    suspend fun saveFile(projectId: String, fileName: String, newContent: String) = withContext(Dispatchers.IO) {
        val projectDir = File(baseDir, projectId)
        val file = File(projectDir, fileName)
        file.writeText(newContent)

        // Update in-memory state
        val updated = _activeProjectFiles.value.map {
            if (it.name == fileName) {
                it.copy(content = newContent, isModified = false, lastSavedTimestamp = System.currentTimeMillis())
            } else it
        }
        _activeProjectFiles.value = updated
    }

    suspend fun createFile(projectId: String, fileName: String, initialContent: String = ""): ProjectFile = withContext(Dispatchers.IO) {
        val projectDir = File(baseDir, projectId)
        val file = File(projectDir, fileName)
        if (!file.exists()) {
            file.writeText(initialContent)
        }
        loadProjectFiles(projectId)
        ProjectFile(
            id = fileName,
            projectId = projectId,
            name = fileName,
            relativePath = fileName,
            content = initialContent,
            language = LanguageType.fromFileName(fileName)
        )
    }

    suspend fun deleteFile(projectId: String, fileName: String) = withContext(Dispatchers.IO) {
        val projectDir = File(baseDir, projectId)
        val file = File(projectDir, fileName)
        if (file.exists()) {
            file.delete()
        }
        loadProjectFiles(projectId)
    }

    suspend fun deleteProject(projectId: String) = withContext(Dispatchers.IO) {
        val dir = File(baseDir, projectId)
        if (dir.exists()) {
            dir.deleteRecursively()
        }
        loadProjectsFromDisk()
    }

    suspend fun exportProjectZip(projectId: String): File = withContext(Dispatchers.IO) {
        val projectDir = File(baseDir, projectId)
        val zipFile = File(context.cacheDir, "$projectId.zip")
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            projectDir.listFiles { f -> !f.name.startsWith(".") }?.forEach { f ->
                if (f.isFile) {
                    val entry = ZipEntry(f.name)
                    zos.putNextEntry(entry)
                    zos.write(f.readBytes())
                    zos.closeEntry()
                }
            }
        }
        zipFile
    }
}
