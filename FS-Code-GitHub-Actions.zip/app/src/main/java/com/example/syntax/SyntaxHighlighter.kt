package com.example.syntax

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import com.example.model.LanguageType
import com.example.ui.theme.*
import java.util.regex.Pattern

object SyntaxHighlighter {

    fun highlight(
        code: String,
        language: LanguageType,
        searchQuery: String = "",
        bracketMatchIndex: Int = -1
    ): AnnotatedString {
        if (code.isEmpty()) return AnnotatedString("")

        return buildAnnotatedString {
            append(code)

            when (language) {
                LanguageType.PYTHON -> applyPythonHighlighting(code)
                LanguageType.JAVASCRIPT -> applyJavaScriptHighlighting(code)
                LanguageType.CPP -> applyCppHighlighting(code)
                LanguageType.HTML -> applyHtmlHighlighting(code)
                LanguageType.CSS -> applyCssHighlighting(code)
                LanguageType.JSON -> applyJsonHighlighting(code)
                LanguageType.KOTLIN -> applyKotlinHighlighting(code)
                LanguageType.MARKDOWN -> applyMarkdownHighlighting(code)
                LanguageType.PLAIN_TEXT -> { /* Plain text, no default syntax rules */ }
            }

            // Search query highlight if active
            if (searchQuery.isNotEmpty()) {
                var index = code.indexOf(searchQuery, ignoreCase = true)
                while (index != -1) {
                    addStyle(
                        SpanStyle(
                            background = Color(0x66F1C40F),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        ),
                        index,
                        index + searchQuery.length
                    )
                    index = code.indexOf(searchQuery, index + searchQuery.length, ignoreCase = true)
                }
            }

            // Bracket matching highlight if cursor is on bracket
            if (bracketMatchIndex in code.indices) {
                addStyle(
                    SpanStyle(
                        background = Color(0x4456B6C2),
                        fontWeight = FontWeight.ExtraBold
                    ),
                    bracketMatchIndex,
                    bracketMatchIndex + 1
                )
            }
        }
    }

    private fun AnnotatedString.Builder.applyPythonHighlighting(code: String) {
        // Strings ("..." or '...')
        applyRegex(code, "\"[^\"]*\"|'[^']*'", SpanStyle(color = SyntaxString))
        // Comments (# ...)
        applyRegex(code, "#.*$", SpanStyle(color = SyntaxComment))
        // Numbers
        applyRegex(code, "\\b\\d+(\\.\\d+)?\\b", SpanStyle(color = SyntaxNumber))
        // Keywords
        val keywords = "\\b(def|class|import|from|as|return|if|elif|else|for|while|break|continue|try|except|finally|with|lambda|yield|pass|None|True|False|and|or|not|in|is|async|await)\\b"
        applyRegex(code, keywords, SpanStyle(color = SyntaxKeyword, fontWeight = FontWeight.SemiBold))
        // Builtins / Functions
        applyRegex(code, "\\b(print|len|range|enumerate|zip|map|filter|int|str|float|list|dict|set|tuple|open|type|sum|min|max|abs)\\b", SpanStyle(color = SyntaxFunction))
        // Decorators
        applyRegex(code, "@\\w+", SpanStyle(color = SyntaxOperator))
    }

    private fun AnnotatedString.Builder.applyJavaScriptHighlighting(code: String) {
        // Strings (template strings `...`, "...", '...')
        applyRegex(code, "`[^`]*`|\"[^\"]*\"|'[^']*'", SpanStyle(color = SyntaxString))
        // Comments (// ... or /* ... */)
        applyRegex(code, "//.*$|/\\*[\\s\\S]*?\\*/", SpanStyle(color = SyntaxComment))
        // Numbers
        applyRegex(code, "\\b\\d+(\\.\\d+)?\\b", SpanStyle(color = SyntaxNumber))
        // Keywords
        val keywords = "\\b(function|const|let|var|return|if|else|for|while|switch|case|break|default|try|catch|finally|throw|async|await|class|extends|import|export|new|this|typeof|instanceof|true|false|null|undefined|yield)\\b"
        applyRegex(code, keywords, SpanStyle(color = SyntaxKeyword, fontWeight = FontWeight.SemiBold))
        // Builtin console, document, window, Math
        applyRegex(code, "\\b(console|document|window|Math|JSON|Promise|Array|Object|String|Number|Boolean|fetch|setTimeout|setInterval)\\b", SpanStyle(color = SyntaxType, fontWeight = FontWeight.Medium))
        // Methods call name()
        applyRegex(code, "\\b([a-zA-Z_\$][a-zA-Z0-9_\$]*)(?=\\()", SpanStyle(color = SyntaxFunction))
    }

    private fun AnnotatedString.Builder.applyCppHighlighting(code: String) {
        // Preprocessor (#include, #define, etc.)
        applyRegex(code, "^\\s*#\\w+.*$", SpanStyle(color = SyntaxKeyword, fontWeight = FontWeight.Bold))
        // Strings
        applyRegex(code, "\"[^\"]*\"|'[^']*'", SpanStyle(color = SyntaxString))
        // Comments
        applyRegex(code, "//.*$|/\\*[\\s\\S]*?\\*/", SpanStyle(color = SyntaxComment))
        // Numbers
        applyRegex(code, "\\b\\d+(\\.\\d+)?(f|u|l|ul)?\\b", SpanStyle(color = SyntaxNumber))
        // Types
        applyRegex(code, "\\b(int|float|double|char|void|bool|auto|long|short|unsigned|signed|size_t|string|vector|map|pair)\\b", SpanStyle(color = SyntaxType))
        // Keywords
        val keywords = "\\b(using|namespace|class|struct|public|private|protected|virtual|template|typename|return|if|else|for|while|do|switch|case|break|new|delete|const|static|inline|explicit|friend|override)\\b"
        applyRegex(code, keywords, SpanStyle(color = SyntaxKeyword, fontWeight = FontWeight.SemiBold))
        // std::cout, std::cin, printf
        applyRegex(code, "\\b(cout|cin|endl|printf|scanf|malloc|free)\\b", SpanStyle(color = SyntaxFunction))
    }

    private fun AnnotatedString.Builder.applyHtmlHighlighting(code: String) {
        // Comments <!-- ... -->
        applyRegex(code, "<!--[\\s\\S]*?-->", SpanStyle(color = SyntaxComment))
        // Tags (<div, </div, etc.)
        applyRegex(code, "</?[a-zA-Z0-9_-]+", SpanStyle(color = SyntaxTag, fontWeight = FontWeight.Medium))
        // Attributes (class=, id=)
        applyRegex(code, "\\b[a-zA-Z0-9_-]+(?==)", SpanStyle(color = SyntaxAttribute))
        // String attribute values
        applyRegex(code, "\"[^\"]*\"|'[^']*'", SpanStyle(color = SyntaxString))
    }

    private fun AnnotatedString.Builder.applyCssHighlighting(code: String) {
        // Comments
        applyRegex(code, "/\\*[\\s\\S]*?\\*/", SpanStyle(color = SyntaxComment))
        // Selectors
        applyRegex(code, "[.#]?[a-zA-Z0-9_-]+(?=\\s*\\{)", SpanStyle(color = SyntaxFunction))
        // Properties
        applyRegex(code, "[a-zA-Z-]+(?=:)", SpanStyle(color = SyntaxTag))
        // Colors & units
        applyRegex(code, "#[0-9a-fA-F]{3,8}|\\b\\d+(px|em|rem|%|vh|vw|s|ms)\\b", SpanStyle(color = SyntaxNumber))
    }

    private fun AnnotatedString.Builder.applyJsonHighlighting(code: String) {
        // Keys
        applyRegex(code, "\"[^\"]*\"(?=\\s*:)", SpanStyle(color = SyntaxTag))
        // String values
        applyRegex(code, "(?<=:\\s*)\"[^\"]*\"", SpanStyle(color = SyntaxString))
        // Numbers
        applyRegex(code, "\\b\\d+(\\.\\d+)?\\b", SpanStyle(color = SyntaxNumber))
        // Booleans & Null
        applyRegex(code, "\\b(true|false|null)\\b", SpanStyle(color = SyntaxKeyword))
    }

    private fun AnnotatedString.Builder.applyKotlinHighlighting(code: String) {
        applyRegex(code, "\"[^\"]*\"|'[^']*'", SpanStyle(color = SyntaxString))
        applyRegex(code, "//.*$|/\\*[\\s\\S]*?\\*/", SpanStyle(color = SyntaxComment))
        applyRegex(code, "\\b\\d+(\\.\\d+)?[fFL]?\\b", SpanStyle(color = SyntaxNumber))
        val keywords = "\\b(fun|val|var|class|interface|object|package|import|return|if|else|when|for|while|is|as|null|true|false|private|public|protected|internal|override|companion|data|sealed|inline)\\b"
        applyRegex(code, keywords, SpanStyle(color = SyntaxKeyword, fontWeight = FontWeight.SemiBold))
        applyRegex(code, "\\b(println|print|listOf|mapOf|setOf|run|let|also|apply|with)\\b", SpanStyle(color = SyntaxFunction))
    }

    private fun AnnotatedString.Builder.applyMarkdownHighlighting(code: String) {
        // Headers (# ...)
        applyRegex(code, "^#{1,6}\\s.*$", SpanStyle(color = SyntaxKeyword, fontWeight = FontWeight.Bold))
        // Code blocks ```...```
        applyRegex(code, "```[\\s\\S]*?```|`[^`]+`", SpanStyle(color = SyntaxString, background = Color(0x335C6370)))
        // Links [text](url)
        applyRegex(code, "\\[[^\\]]+\\]\\([^\\)]+\\)", SpanStyle(color = SyntaxFunction))
        // Quotes > ...
        applyRegex(code, "^>\\s.*$", SpanStyle(color = SyntaxComment))
    }

    private fun AnnotatedString.Builder.applyRegex(code: String, regex: String, style: SpanStyle) {
        try {
            val pattern = Pattern.compile(regex, Pattern.MULTILINE)
            val matcher = pattern.matcher(code)
            while (matcher.find()) {
                val start = matcher.start()
                val end = matcher.end()
                if (start in code.indices && end <= code.length && start < end) {
                    addStyle(style, start, end)
                }
            }
        } catch (_: Exception) {
            // Graceful fallback on complex regex
        }
    }
}
