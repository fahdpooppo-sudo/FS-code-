package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.FileProvider
import com.example.model.Project
import com.example.model.ProjectFile
import com.example.model.ProjectTemplate
import com.example.model.SettingsState
import com.example.repository.ProjectRepository
import com.example.runner.ExecutionEngine
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.FsBackgroundDark
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var repository: ProjectRepository
    private lateinit var executionEngine: ExecutionEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        repository = ProjectRepository(this)
        executionEngine = ExecutionEngine(this)

        setContent {
            val coroutineScope = rememberCoroutineScope()
            val context = LocalContext.current

            var settings by remember { mutableStateOf(SettingsState()) }
            val projects by repository.projects.collectAsState()
            val activeFiles by repository.activeProjectFiles.collectAsState()

            var currentScreen by remember { mutableStateOf("HOME") }
            var activeProject by remember { mutableStateOf<Project?>(null) }

            // Initialize repository on first launch
            LaunchedEffect(Unit) {
                repository.initialize()
            }

            // Apply RTL layout direction if language is Arabic
            val layoutDirection = if (settings.language.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                MyApplicationTheme(darkTheme = settings.isDarkMode) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = FsBackgroundDark
                    ) {
                        when (currentScreen) {
                            "HOME" -> {
                                HomeScreen(
                                    projects = projects,
                                    settings = settings,
                                    onOpenProject = { project ->
                                        activeProject = project
                                        coroutineScope.launch {
                                            repository.loadProjectFiles(project.id)
                                            currentScreen = "EDITOR"
                                        }
                                    },
                                    onCreateProject = { name, template, desc ->
                                        coroutineScope.launch {
                                            val newProj = repository.createProject(name, template, desc)
                                            activeProject = newProj
                                            repository.loadProjectFiles(newProj.id)
                                            currentScreen = "EDITOR"
                                        }
                                    },
                                    onDeleteProject = { projectId ->
                                        coroutineScope.launch {
                                            repository.deleteProject(projectId)
                                        }
                                    },
                                    onExportZip = { projectId ->
                                        coroutineScope.launch {
                                            try {
                                                val zipFile = repository.exportProjectZip(projectId)
                                                val uri = FileProvider.getUriForFile(
                                                    context,
                                                    "${context.packageName}.fileprovider",
                                                    zipFile
                                                )
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "application/zip"
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "Share FS Code Project ZIP"))
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Exported project: $projectId", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    onSettingsChanged = { newSettings ->
                                        settings = newSettings
                                    },
                                    onOpenFsBuilder = {
                                        currentScreen = "BUILDER"
                                    }
                                )
                            }

                            "BUILDER" -> {
                                com.example.ui.screens.FsBuilderScreen(
                                    currentProject = activeProject,
                                    repository = repository,
                                    onBack = { currentScreen = "HOME" }
                                )
                            }

                            "EDITOR" -> {
                                val proj = activeProject
                                if (proj != null) {
                                    EditorScreen(
                                        project = proj,
                                        files = activeFiles,
                                        settings = settings,
                                        executionEngine = executionEngine,
                                        repository = repository,
                                        onBack = {
                                            currentScreen = "HOME"
                                        },
                                        onSaveFile = { fileName, content ->
                                            coroutineScope.launch {
                                                repository.saveFile(proj.id, fileName, content)
                                            }
                                        },
                                        onCreateFile = { fileName, content ->
                                            coroutineScope.launch {
                                                repository.createFile(proj.id, fileName, content)
                                            }
                                        },
                                        onDeleteFile = { fileName ->
                                            coroutineScope.launch {
                                                repository.deleteFile(proj.id, fileName)
                                            }
                                        },
                                        onExportZip = {
                                            coroutineScope.launch {
                                                try {
                                                    val zipFile = repository.exportProjectZip(proj.id)
                                                    val uri = FileProvider.getUriForFile(
                                                        context,
                                                        "${context.packageName}.fileprovider",
                                                        zipFile
                                                    )
                                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                                        type = "application/zip"
                                                        putExtra(Intent.EXTRA_STREAM, uri)
                                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                    }
                                                    context.startActivity(Intent.createChooser(intent, "Share FS Code Project ZIP"))
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "Project exported to cache", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
