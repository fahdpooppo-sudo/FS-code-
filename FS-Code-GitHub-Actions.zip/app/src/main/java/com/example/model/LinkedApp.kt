package com.example.model

data class LinkedApp(
    val id: String,
    val name: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val descriptionTr: String,
    val badge: String = "f-Studio",
    val status: String = "Available",
    val isPrimary: Boolean = false,
    val iconKey: String = "build"
)

object DefaultLinkedApps {
    fun getList(): List<LinkedApp> = listOf(
        LinkedApp(
            id = "fs_builder",
            name = "FS Builder",
            descriptionEn = "Visual app layout designer & UI generator integrated with FS Code projects",
            descriptionAr = "منشئ التطبيقات المرئي ومصمم الواجهات التفاعلي المتكامل مع مشاريع FS Code",
            descriptionTr = "FS Code projeleriyle entegre görsel uygulama düzeni ve arayüz tasarımcısı",
            badge = "Ecosystem",
            status = "Connected",
            isPrimary = true,
            iconKey = "widgets"
        ),
        LinkedApp(
            id = "fs_account",
            name = "FS Account",
            descriptionEn = "Unified f-Studio Apps identity, license management, and developer profile",
            descriptionAr = "هوية f-Studio Apps الموحدة، إدارة التراخيص، وملف المطور الشخصي",
            descriptionTr = "Birleşik f-Studio kimliği ve geliştirici profili",
            badge = "Auth",
            status = "Ready",
            isPrimary = false,
            iconKey = "account"
        ),
        LinkedApp(
            id = "fs_cloud",
            name = "FS Cloud Storage",
            descriptionEn = "Encrypted cloud backup, device-to-device sync, and collaborative workspace",
            descriptionAr = "نسخ احتياطي مشفر، مزامنة فورية بين الأجهزة، ومساحة عمل تعاونية",
            descriptionTr = "Şifreli bulut yedekleme ve cihazlar arası senkronizasyon",
            badge = "Storage",
            status = "Optional",
            isPrimary = false,
            iconKey = "cloud"
        ),
        LinkedApp(
            id = "fs_terminal",
            name = "FS Terminal Native",
            descriptionEn = "Full Linux-compatible environment, package manager, and shell execution",
            descriptionAr = "بيئة شل متوافقة مع لينكس ومدير حزم ومحاكي طرفية متطور",
            descriptionTr = "Gelişmiş Linux uyumlu terminal ve paket yöneticisi",
            badge = "Native",
            status = "Ready",
            isPrimary = false,
            iconKey = "terminal"
        )
    )
}
