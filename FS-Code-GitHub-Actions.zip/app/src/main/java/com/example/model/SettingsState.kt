package com.example.model

enum class AppLanguage(val code: String, val displayName: String, val isRtl: Boolean) {
    ARABIC("ar", "العربية", true),
    TURKISH("tr", "Türkçe", false),
    ENGLISH("en", "English", false)
}

data class SettingsState(
    val language: AppLanguage = AppLanguage.ARABIC,
    val isDarkMode: Boolean = true,
    val editorFontSize: Int = 14,
    val tabSize: Int = 4,
    val showLineNumbers: Boolean = true,
    val wordWrap: Boolean = false,
    val autoSave: Boolean = true,
    val highlightMatchingBrackets: Boolean = true,
    val showKeyboardHelper: Boolean = true
)
