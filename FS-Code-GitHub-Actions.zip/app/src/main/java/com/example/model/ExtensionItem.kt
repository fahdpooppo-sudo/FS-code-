package com.example.model

data class ExtensionItem(
    val id: String,
    val name: String,
    val publisher: String = "f-Studio Team",
    val descriptionEn: String,
    val descriptionAr: String,
    val descriptionTr: String,
    val version: String = "1.0.0",
    val isInstalled: Boolean = true,
    val isEnabled: Boolean = true,
    val category: String = "Tools",
    val rating: Float = 4.9f,
    val downloads: String = "24K"
)

object DefaultExtensions {
    fun getList(): List<ExtensionItem> = listOf(
        ExtensionItem(
            id = "ext_python_pro",
            name = "Python Sandbox Pro",
            publisher = "f-Studio Apps",
            descriptionEn = "Isolated execution environment, auto-completion, and PEP8 linter for Python 3",
            descriptionAr = "بيئة تشغيل بايثون معزولة، إكمال تلقائي، وفاحص صياغة PEP8",
            descriptionTr = "İzole çalışma ortamı, otomatik tamamlama ve PEP8 denetleyici",
            version = "2.4.1",
            isInstalled = true,
            isEnabled = true,
            category = "Language",
            rating = 5.0f,
            downloads = "85K"
        ),
        ExtensionItem(
            id = "ext_web_inspector",
            name = "Web & JS Live Runtime",
            publisher = "f-Studio Apps",
            descriptionEn = "Embedded browser rendering engine with DOM inspector and JS console bridge",
            descriptionAr = "محرك عرض ويب مدمج مع متصفح النظام، فاحص DOM، وجسر سجلات JS",
            descriptionTr = "Gömülü tarayıcı motoru, DOM denetleyicisi ve JS konsol köprüsü",
            version = "3.1.0",
            isInstalled = true,
            isEnabled = true,
            category = "Runtime",
            rating = 4.9f,
            downloads = "62K"
        ),
        ExtensionItem(
            id = "ext_cpp_clang",
            name = "C++ Instant Clang Tools",
            publisher = "f-Studio Apps",
            descriptionEn = "Instant C/C++ syntax analysis, compilation simulation, and format on save",
            descriptionAr = "ترجمة فورية، فحص أخطاء C++ المتقدم، وتنسيق الأكواد التلقائي",
            descriptionTr = "Anında C/C++ sözdizimi analizi, derleme simülasyonu ve otomatik biçimlendirme",
            version = "1.8.2",
            isInstalled = true,
            isEnabled = true,
            category = "Compiler",
            rating = 4.8f,
            downloads = "41K"
        ),
        ExtensionItem(
            id = "ext_dark_gold",
            name = "FS Dark Gold Pro Theme",
            publisher = "f-Studio Design",
            descriptionEn = "Signature quiet dark charcoal theme with elegant gold syntax highlights",
            descriptionAr = "السمة الرسمية الفاخرة باللون الأسود الفاحم واللمسات الذهبية الأنيقة",
            descriptionTr = "Zarif altın sözdizimi vurgulu imza koyu tema",
            version = "2.0.0",
            isInstalled = true,
            isEnabled = true,
            category = "Theme",
            rating = 5.0f,
            downloads = "120K"
        ),
        ExtensionItem(
            id = "ext_git_sync",
            name = "FS Git & Project Sync",
            publisher = "f-Studio Cloud",
            descriptionEn = "Local version tracking, diff inspector, and ZIP project exports",
            descriptionAr = "تتبع النسخ المحلية، فاحص الفروقات، وتصدير المشاريع كملف مضغوط ZIP",
            descriptionTr = "Yerel sürüm takibi, fark denetleyici ve ZIP dışa aktarma",
            version = "1.5.0",
            isInstalled = false,
            isEnabled = false,
            category = "VCS",
            rating = 4.7f,
            downloads = "33K"
        )
    )
}
