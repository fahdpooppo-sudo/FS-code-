package com.example.model

enum class ExecutionStatus {
    IDLE,
    RUNNING,
    SUCCESS,
    ERROR
}

data class OutputLog(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isError: Boolean = false,
    val isSystem: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class ExecutionResult(
    val status: ExecutionStatus = ExecutionStatus.IDLE,
    val logs: List<OutputLog> = emptyList(),
    val exitCode: Int = 0,
    val executionTimeMs: Long = 0,
    val runnerName: String = "",
    val errorLine: Int? = null,
    val rawOutput: String = ""
)
