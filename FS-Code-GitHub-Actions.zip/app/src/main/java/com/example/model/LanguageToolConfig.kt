package com.example.model

enum class ToolActionType {
    RUN_MAIN,
    RUN_IN_BROWSER,
    COMPILE_CONSOLE,
    WEB_PREVIEW,
    FORMAT_CODE,
    TOGGLE_COMMENT,
    INDENT_FORWARD,
    INDENT_BACKWARD,
    SEARCH_REPLACE,
    INSERT_SNIPPET,
    CLEAR_CONSOLE,
    VIEW_STATS
}

data class LanguageToolButton(
    val id: String,
    val title: String,
    val actionType: ToolActionType,
    val iconName: String,
    val isEnabled: Boolean = true,
    val snippetTemplate: String = ""
)

data class LanguageToolbarConfig(
    val language: LanguageType,
    val buttons: List<LanguageToolButton>
)

object DefaultLanguageToolbars {
    fun getDefaultConfigs(): Map<LanguageType, List<LanguageToolButton>> {
        return mapOf(
            LanguageType.PYTHON to listOf(
                LanguageToolButton("py_run", "تشغيل بايثون المعزول (Run Sandbox)", ToolActionType.RUN_MAIN, "play_arrow"),
                LanguageToolButton("py_format", "تنسيق الكود (Format)", ToolActionType.FORMAT_CODE, "auto_fix_high"),
                LanguageToolButton("py_indent", "إزاحة لليمين (Indent)", ToolActionType.INDENT_FORWARD, "format_indent_increase"),
                LanguageToolButton("py_dedent", "إزاحة لليسار (Dedent)", ToolActionType.INDENT_BACKWARD, "format_indent_decrease"),
                LanguageToolButton("py_comment", "تعليق / إلغاء (Comment #)", ToolActionType.TOGGLE_COMMENT, "comment"),
                LanguageToolButton("py_def", "إضافة دالة (def)", ToolActionType.INSERT_SNIPPET, "code", snippetTemplate = "def function_name():\n    pass\n")
            ),
            LanguageType.JAVASCRIPT to listOf(
                LanguageToolButton("js_browser", "تشغيل في المتصفح (Run in Browser)", ToolActionType.RUN_IN_BROWSER, "open_in_browser"),
                LanguageToolButton("js_run", "تشغيل الكونسول (Run Node/V8)", ToolActionType.RUN_MAIN, "play_arrow"),
                LanguageToolButton("js_format", "تنسيق جافاسكريبت (Prettier)", ToolActionType.FORMAT_CODE, "auto_fix_high"),
                LanguageToolButton("js_comment", "تعليق (//)", ToolActionType.TOGGLE_COMMENT, "comment"),
                LanguageToolButton("js_log", "console.log()", ToolActionType.INSERT_SNIPPET, "terminal", snippetTemplate = "console.log();")
            ),
            LanguageType.HTML to listOf(
                LanguageToolButton("html_preview", "معاينة حية (Live Preview)", ToolActionType.WEB_PREVIEW, "preview"),
                LanguageToolButton("html_browser", "فتح بالمتصفح (System Browser)", ToolActionType.RUN_IN_BROWSER, "open_in_browser"),
                LanguageToolButton("html_format", "تنسيق HTML (Format)", ToolActionType.FORMAT_CODE, "auto_fix_high"),
                LanguageToolButton("html_div", "عنصر <div/>", ToolActionType.INSERT_SNIPPET, "crop_square", snippetTemplate = "<div class=\"\">\n    \n</div>")
            ),
            LanguageType.CPP to listOf(
                LanguageToolButton("cpp_compile", "ترجمة فورية وتشغيل (Compile & Run)", ToolActionType.COMPILE_CONSOLE, "memory"),
                LanguageToolButton("cpp_format", "تنسيق Clang (Clang-Format)", ToolActionType.FORMAT_CODE, "auto_fix_high"),
                LanguageToolButton("cpp_comment", "تعليق (//)", ToolActionType.TOGGLE_COMMENT, "comment"),
                LanguageToolButton("cpp_cout", "std::cout", ToolActionType.INSERT_SNIPPET, "arrow_forward", snippetTemplate = "std::cout <<  << std::endl;")
            )
        )
    }
}
