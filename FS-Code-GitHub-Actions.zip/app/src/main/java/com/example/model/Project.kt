package com.example.model

enum class ProjectTemplate(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val titleTr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val primaryLanguage: LanguageType,
    val iconName: String
) {
    PYTHON_APP(
        id = "python_app",
        titleEn = "Python Sandbox App",
        titleAr = "مشروع بايثون معزول",
        titleTr = "İzole Python Uygulaması",
        descriptionEn = "Sandboxed Python 3 script with math, algorithms, and interactive stdin/stdout",
        descriptionAr = "بيئة بايثون 3 معزولة مع الرياضيات، الحسابات، ودعم الإدخال التفاعلي",
        primaryLanguage = LanguageType.PYTHON,
        iconName = "terminal"
    ),
    WEB_APP(
        id = "web_app",
        titleEn = "Web App (HTML/JS/CSS)",
        titleAr = "مشروع ويب متكامل",
        titleTr = "Web Uygulaması (HTML/JS/CSS)",
        descriptionEn = "Interactive frontend with live browser preview and real-time JavaScript runner",
        descriptionAr = "تطبيق ويب تفاعلي مع معاينة فورية في المتصفح وتنفيذ جافاسكريبت المباشر",
        primaryLanguage = LanguageType.HTML,
        iconName = "globe"
    ),
    CPP_CLI(
        id = "cpp_cli",
        titleEn = "C++ Console Tool",
        titleAr = "أداة وحدة تحكم C++",
        titleTr = "C++ Konsol Aracı",
        descriptionEn = "Native C++ algorithm runner with instant compilation and console diagnostics",
        descriptionAr = "برنامج C++ مع ترجمة فورية ووحدة تحكم تفاعلية مدمجة",
        primaryLanguage = LanguageType.CPP,
        iconName = "memory"
    ),
    EMPTY(
        id = "empty",
        titleEn = "Empty Project",
        titleAr = "مشروع فارغ",
        titleTr = "Boş Proje",
        descriptionEn = "Clean directory to start coding any language from scratch",
        descriptionAr = "مجلد نظيف لبدء كتابة الأكواد لأي لغة من الصفر",
        primaryLanguage = LanguageType.PLAIN_TEXT,
        iconName = "folder"
    )
}

data class Project(
    val id: String,
    val name: String,
    val description: String = "",
    val template: ProjectTemplate = ProjectTemplate.PYTHON_APP,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val filesCount: Int = 1,
    val primaryLanguage: LanguageType = template.primaryLanguage
)
