package com.example.model

data class ProjectFile(
    val id: String,
    val projectId: String,
    val name: String,
    val relativePath: String,
    val content: String = "",
    val isDirectory: Boolean = false,
    val language: LanguageType = LanguageType.fromFileName(name),
    val isModified: Boolean = false,
    val lastSavedTimestamp: Long = System.currentTimeMillis()
)
