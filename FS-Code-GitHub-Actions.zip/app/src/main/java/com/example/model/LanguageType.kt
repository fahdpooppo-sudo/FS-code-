package com.example.model

enum class LanguageType(
    val id: String,
    val displayName: String,
    val primaryExtension: String,
    val supportedExtensions: List<String>,
    val badgeColorHex: Long,
    val defaultKeywords: List<String>,
    val commonSnippets: List<String>,
    val defaultQuickSymbols: List<String>
) {
    PYTHON(
        id = "python",
        displayName = "Python",
        primaryExtension = "py",
        supportedExtensions = listOf("py", "pyw"),
        badgeColorHex = 0xFF3776AB,
        defaultKeywords = listOf(
            "def", "class", "import", "from", "as", "return", "if", "elif", "else",
            "for", "while", "break", "continue", "try", "except", "finally", "with",
            "lambda", "yield", "pass", "None", "True", "False", "and", "or", "not", "in", "is"
        ),
        commonSnippets = listOf("def func():", "for i in range():", "if __name__ == '__main__':", "import math", "print()"),
        defaultQuickSymbols = listOf(":", "(", ")", "{", "}", "[", "]", "=", "\"", "'", "#", ",", ".", "->", "+", "-", "*", "/")
    ),
    JAVASCRIPT(
        id = "javascript",
        displayName = "JavaScript",
        primaryExtension = "js",
        supportedExtensions = listOf("js", "mjs", "cjs"),
        badgeColorHex = 0xFFF7DF1E,
        defaultKeywords = listOf(
            "function", "const", "let", "var", "return", "if", "else", "for", "while",
            "switch", "case", "break", "default", "try", "catch", "finally", "throw",
            "async", "await", "class", "extends", "import", "export", "new", "this",
            "typeof", "instanceof", "true", "false", "null", "undefined"
        ),
        commonSnippets = listOf("console.log()", "const name = () => {}", "function run() {}", "document.getElementById()", "addEventListener()"),
        defaultQuickSymbols = listOf(";", "{", "}", "(", ")", "=>", "=", "\"", "'", "[", "]", ".", ",", "+", "-", "*", "/", ":", "$")
    ),
    HTML(
        id = "html",
        displayName = "HTML5",
        primaryExtension = "html",
        supportedExtensions = listOf("html", "htm"),
        badgeColorHex = 0xFFE34F26,
        defaultKeywords = listOf(
            "html", "head", "body", "div", "span", "p", "a", "h1", "h2", "h3", "button",
            "input", "script", "style", "link", "meta", "title", "ul", "ol", "li", "form"
        ),
        commonSnippets = listOf("<!DOCTYPE html>", "<div class=\"\">", "<button id=\"\">", "<script>", "<style>"),
        defaultQuickSymbols = listOf("<", ">", "</", "\"", "'", "=", "/", "!", "-", "{", "}", ";", ":", "(", ")")
    ),
    CSS(
        id = "css",
        displayName = "CSS3",
        primaryExtension = "css",
        supportedExtensions = listOf("css"),
        badgeColorHex = 0xFF1572B6,
        defaultKeywords = listOf(
            "color", "background", "margin", "padding", "display", "flex", "grid",
            "width", "height", "border", "font-family", "font-size", "align-items", "justify-content"
        ),
        commonSnippets = listOf("display: flex;", "justify-content: center;", "margin: 0 auto;", "@media screen"),
        defaultQuickSymbols = listOf("{", "}", ":", ";", "#", ".", "%", "px", "rem", "(", ")", "\"", "'")
    ),
    CPP(
        id = "cpp",
        displayName = "C++",
        primaryExtension = "cpp",
        supportedExtensions = listOf("cpp", "cc", "cxx", "hpp", "h"),
        badgeColorHex = 0xFF00599C,
        defaultKeywords = listOf(
            "#include", "using", "namespace", "int", "float", "double", "char", "void", "bool",
            "auto", "class", "struct", "public", "private", "protected", "virtual", "template",
            "return", "if", "else", "for", "while", "do", "switch", "case", "break", "new", "delete", "const"
        ),
        commonSnippets = listOf("#include <iostream>", "using namespace std;", "int main() { return 0; }", "std::cout <<  << std::endl;", "std::cin >> ;"),
        defaultQuickSymbols = listOf(";", "{", "}", "(", ")", "::", "<<", ">>", "<", ">", "=", "\"", "'", "[", "]", "&", "*", "->", "#")
    ),
    KOTLIN(
        id = "kotlin",
        displayName = "Kotlin",
        primaryExtension = "kt",
        supportedExtensions = listOf("kt", "kts"),
        badgeColorHex = 0xFF7F52FF,
        defaultKeywords = listOf(
            "fun", "val", "var", "class", "interface", "object", "package", "import",
            "return", "if", "else", "when", "for", "while", "is", "as", "null", "true", "false"
        ),
        commonSnippets = listOf("fun main() {}", "val result = ", "println()", "data class "),
        defaultQuickSymbols = listOf(";", "{", "}", "(", ")", ":", "=", "->", "\"", "'", "[", "]", "?", "!", ".", ",")
    ),
    JSON(
        id = "json",
        displayName = "JSON",
        primaryExtension = "json",
        supportedExtensions = listOf("json"),
        badgeColorHex = 0xFF02569B,
        defaultKeywords = listOf("true", "false", "null"),
        commonSnippets = listOf("\"key\": \"value\"", "[]", "{}"),
        defaultQuickSymbols = listOf("{", "}", "[", "]", ":", "\"", ",", "true", "false", "null")
    ),
    MARKDOWN(
        id = "markdown",
        displayName = "Markdown",
        primaryExtension = "md",
        supportedExtensions = listOf("md", "markdown"),
        badgeColorHex = 0xFF083FA1,
        defaultKeywords = listOf(),
        commonSnippets = listOf("# Heading 1", "## Heading 2", "```code```", "- [ ] Task", "[Link](url)"),
        defaultQuickSymbols = listOf("#", "*", "`", "-", "[", "]", "(", ")", ">", "_", "!", "|")
    ),
    PLAIN_TEXT(
        id = "text",
        displayName = "Plain Text",
        primaryExtension = "txt",
        supportedExtensions = listOf("txt", "log", "env"),
        badgeColorHex = 0xFF888888,
        defaultKeywords = listOf(),
        commonSnippets = listOf(),
        defaultQuickSymbols = listOf("(", ")", "{", "}", "[", "]", "=", "\"", "'", ";", ":", "/", "\\")
    );

    companion object {
        fun fromExtension(ext: String): LanguageType {
            val normalized = ext.lowercase().removePrefix(".")
            return entries.firstOrNull { it.supportedExtensions.contains(normalized) } ?: PLAIN_TEXT
        }

        fun fromFileName(fileName: String): LanguageType {
            val ext = fileName.substringAfterLast('.', "")
            return fromExtension(ext)
        }
    }
}
