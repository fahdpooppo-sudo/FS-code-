package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("FS Code", appName)
  }

  @Test
  fun `verify language extension detection`() {
    assertEquals(com.example.model.LanguageType.PYTHON, com.example.model.LanguageType.fromFileName("script.py"))
    assertEquals(com.example.model.LanguageType.JAVASCRIPT, com.example.model.LanguageType.fromFileName("app.js"))
    assertEquals(com.example.model.LanguageType.CPP, com.example.model.LanguageType.fromFileName("main.cpp"))
    assertEquals(com.example.model.LanguageType.HTML, com.example.model.LanguageType.fromFileName("index.html"))
  }
}
